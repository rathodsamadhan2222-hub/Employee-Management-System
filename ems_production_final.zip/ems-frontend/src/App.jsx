// src/App.jsx
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';

import ProtectedRoute  from './components/ProtectedRoute';
import Login           from './pages/login';
import Register        from './pages/register';
import Dashboard       from './pages/dashboard';
import Employees       from './pages/employees';
import AddEmployee     from './pages/addemployee';
import EmployeeDetails from './pages/EmployeeDetails';
import EditEmployee    from './pages/EditEmployee';

// Redirect already-logged-in users away from public pages
const PublicRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();
  if (loading) return null;
  return isAuthenticated ? <Navigate to="/" replace /> : children;
};

const App = () => (
  <Routes>
    {/* ── Public ──────────────────────────────────────────────────────── */}
    <Route path="/login"    element={<PublicRoute><Login    /></PublicRoute>} />
    <Route path="/register" element={<PublicRoute><Register /></PublicRoute>} />

    {/* ── Protected — all authenticated roles ─────────────────────────── */}
    <Route path="/"            element={<ProtectedRoute><Dashboard       /></ProtectedRoute>} />
    <Route path="/employees"   element={<ProtectedRoute><Employees       /></ProtectedRoute>} />
    <Route path="/employees/:id"      element={<ProtectedRoute><EmployeeDetails /></ProtectedRoute>} />

    {/* ── Protected — admin + hr only ─────────────────────────────────── */}
    <Route path="/add-employee"       element={<ProtectedRoute roles={['admin','hr']}><AddEmployee  /></ProtectedRoute>} />
    <Route path="/employees/:id/edit" element={<ProtectedRoute roles={['admin','hr']}><EditEmployee /></ProtectedRoute>} />

    {/* ── Settings placeholder ─────────────────────────────────────────── */}
    <Route path="/settings" element={
      <ProtectedRoute>
        <div className="ml-64 p-8 min-h-screen bg-slate-50">
          <h1 className="text-2xl font-bold text-slate-900">Settings</h1>
          <p className="text-slate-500 mt-2">Coming soon.</p>
        </div>
      </ProtectedRoute>
    }/>

    {/* ── Catch-all ────────────────────────────────────────────────────── */}
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes>
);

export default App;
