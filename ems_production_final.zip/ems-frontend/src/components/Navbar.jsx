// src/components/Navbar.jsx
import { useState, useRef, useCallback, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Search, HelpCircle, User, X, Loader2 } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import employeeService from '../services/employeeService';

// ── Search result dropdown ────────────────────────────────────────────────────

const SearchDropdown = ({ results, query, loading, onClose }) => {
  const navigate = useNavigate();

  if (!query) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-2xl overflow-hidden z-50">
      {loading ? (
        <div className="flex items-center justify-center gap-2 p-4 text-slate-500 text-sm font-medium">
          <Loader2 size={16} className="animate-spin" />
          Searching…
        </div>
      ) : results.length === 0 ? (
        <p className="p-4 text-sm text-slate-500 font-medium text-center">
          No employees found for "<span className="font-bold">{query}</span>"
        </p>
      ) : (
        <ul className="divide-y divide-slate-50">
          {results.map((emp) => (
            <li key={emp._id}>
              <button
                onClick={() => {
                  navigate(`/employees/${emp._id}`);
                  onClose();
                }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-slate-50 transition-colors text-left"
              >
                <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs shrink-0">
                  {emp.fullName?.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-slate-900 truncate">{emp.fullName}</p>
                  <p className="text-xs text-slate-500 truncate">{emp.department} · {emp.designation}</p>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full shrink-0 ${
                  emp.status === 'Active' ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-slate-600'
                }`}>
                  {emp.status}
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

// ── Navbar ────────────────────────────────────────────────────────────────────

const Navbar = ({ title }) => {
  const { user } = useAuth();

  const [query,    setQuery]    = useState('');
  const [results,  setResults]  = useState([]);
  const [loading,  setLoading]  = useState(false);
  const [showDrop, setShowDrop] = useState(false);

  const debounceRef   = useRef(null);
  const containerRef  = useRef(null);

  // ── Debounced search ───────────────────────────────────────────────────

  const runSearch = useCallback(async (q) => {
    if (q.trim().length < 2) { setResults([]); setLoading(false); return; }
    setLoading(true);
    try {
      const { data } = await employeeService.search(q.trim());
      setResults(data.data || []);
    } catch {
      setResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const handleSearchChange = (e) => {
    const val = e.target.value;
    setQuery(val);
    setShowDrop(true);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runSearch(val), 350);
  };

  const clearSearch = () => {
    setQuery('');
    setResults([]);
    setShowDrop(false);
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handler = (e) => {
      if (containerRef.current && !containerRef.current.contains(e.target)) {
        setShowDrop(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  return (
    <header className="sticky top-0 z-40 bg-white/80 backdrop-blur-md border-b border-slate-200 ml-64 h-16 flex items-center justify-between px-8">
      <div className="flex items-center gap-4 flex-1">
        <h2 className="text-lg font-semibold text-slate-900 shrink-0">{title}</h2>

        {/* Global search */}
        <div ref={containerRef} className="relative max-w-md w-full ml-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input
            type="text"
            value={query}
            onChange={handleSearchChange}
            onFocus={() => query.length >= 2 && setShowDrop(true)}
            placeholder="Search employees, records..."
            className="w-full pl-10 pr-10 py-2 bg-slate-100 border-transparent focus:bg-white focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 rounded-full text-sm transition-all outline-none border"
          />
          {query && (
            <button
              onClick={clearSearch}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X size={16} />
            </button>
          )}

          {showDrop && (
            <SearchDropdown
              results={results}
              query={query}
              loading={loading}
              onClose={clearSearch}
            />
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 shrink-0">
        <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full relative transition-colors">
          <Bell size={20} />
          <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 border-2 border-white rounded-full" />
        </button>
        <button className="p-2 text-slate-500 hover:bg-slate-100 rounded-full transition-colors">
          <HelpCircle size={20} />
        </button>

        <div className="h-8 w-px bg-slate-200 mx-1" />

        {/* Live user info from AuthContext */}
        <div className="flex items-center gap-3 pl-1">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-semibold text-slate-900 leading-tight">{user?.name || 'Admin'}</p>
            <p className="text-xs text-slate-500 font-medium leading-tight capitalize">{user?.role || 'hr'}</p>
          </div>
          <div className="w-10 h-10 rounded-full bg-blue-100 border-2 border-blue-500 overflow-hidden flex items-center justify-center font-bold text-blue-600 text-sm">
            {user?.name?.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() || <User size={20} />}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
