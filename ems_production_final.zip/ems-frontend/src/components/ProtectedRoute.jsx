// src/components/ProtectedRoute.jsx
// ─── Auth + role guard for react-router v6 ───────────────────────────────────
//
// Usage:
//   <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
//   <Route path="/add-employee" element={
//     <ProtectedRoute roles={['admin','hr']}><AddEmployee /></ProtectedRoute>
//   } />

import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const ProtectedRoute = ({ children, roles }) => {
  const { isAuthenticated, user, loading } = useAuth();
  const location = useLocation();

  // Still verifying token on mount — render nothing to avoid flash of /login
  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-sm font-medium text-slate-500">Loading session…</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    // Save where the user was trying to go so we can redirect after login
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // Role check: if roles prop is given, user must have one of them
  if (roles && !roles.includes(user?.role)) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedRoute;
