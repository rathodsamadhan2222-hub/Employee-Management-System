// src/components/Sidebar.jsx
import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, Users, UserPlus, Settings, LogOut, Loader2 } from 'lucide-react';
import { useState } from 'react';

const Sidebar = () => {
  const { logout, user } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const menuItems = [
    { name: 'Dashboard',    icon: <LayoutDashboard size={20} />, path: '/'             },
    { name: 'Employees',    icon: <Users           size={20} />, path: '/employees'    },
    { name: 'Add Employee', icon: <UserPlus        size={20} />, path: '/add-employee' },
    { name: 'Settings',     icon: <Settings        size={20} />, path: '/settings'     },
  ];

  const handleLogout = async () => {
    setIsLoggingOut(true);
    await logout();           // AuthContext handles navigation to /login
    setIsLoggingOut(false);
  };

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-slate-900 text-white flex flex-col z-50">
      {/* Logo */}
      <div className="p-6">
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-sm font-black">
            HR
          </div>
          <span>Precision</span>
        </h1>
        <p className="text-slate-400 text-xs mt-1 font-medium uppercase tracking-widest">Enterprise Admin</p>
      </div>

      {/* Nav */}
      <nav className="flex-1 mt-4 px-4 space-y-1">
        {menuItems.map((item) => (
          <NavLink
            key={item.name}
            to={item.path}
            end={item.path === '/'}   // exact match for root only
            className={({ isActive }) =>
              `flex items-center gap-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-lg shadow-blue-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800'
              }`
            }
          >
            {item.icon}
            <span className="font-medium">{item.name}</span>
          </NavLink>
        ))}
      </nav>

      {/* User card + logout */}
      <div className="p-4 border-t border-slate-800 space-y-3">
        {/* Logged-in user */}
        <div className="flex items-center gap-3 px-3 py-2">
          <div className="w-9 h-9 rounded-full bg-blue-600 flex items-center justify-center font-bold text-sm shrink-0">
            {user?.name?.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase() || 'U'}
          </div>
          <div className="overflow-hidden">
            <p className="text-sm font-semibold text-white truncate leading-tight">{user?.name || 'Admin'}</p>
            <p className="text-xs text-slate-400 capitalize leading-tight">{user?.role || 'hr'}</p>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          disabled={isLoggingOut}
          className="flex items-center gap-3 w-full px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-all duration-200 disabled:opacity-60 disabled:cursor-not-allowed"
        >
          {isLoggingOut
            ? <Loader2 size={20} className="animate-spin" />
            : <LogOut size={20} />
          }
          <span className="font-medium">{isLoggingOut ? 'Logging out…' : 'Logout'}</span>
        </button>
      </div>
    </aside>
  );
};

export default Sidebar;
