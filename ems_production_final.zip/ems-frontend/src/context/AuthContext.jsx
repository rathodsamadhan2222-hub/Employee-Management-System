// src/context/AuthContext.jsx
// ─── Global auth state ────────────────────────────────────────────────────────
// Provides: user, loading, isAuthenticated, isAdmin, isHR, login, register, logout
// Wrap your entire app in <AuthProvider> (see main.jsx).

import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import authService from '../services/authService';

const AuthContext = createContext(null);

// ─── Provider ─────────────────────────────────────────────────────────────────

export const AuthProvider = ({ children }) => {
  const navigate = useNavigate();

  // Try to restore user from localStorage so page refreshes don't log people out
  const [user,    setUser]    = useState(() => {
    try { return JSON.parse(localStorage.getItem('user')) || null; }
    catch { return null; }
  });
  const [loading, setLoading] = useState(true);   // true while verifying token on mount

  // ── Restore session on mount ──────────────────────────────────────────────
  // Even if user is in localStorage, verify token is still valid with the server.

  useEffect(() => {
    const verify = async () => {
      const token = localStorage.getItem('accessToken');
      if (!token) { setLoading(false); return; }

      try {
        const { data } = await authService.getProfile();
        const freshUser = data.data.user;
        setUser(freshUser);
        localStorage.setItem('user', JSON.stringify(freshUser));
      } catch {
        // Token invalid — api.js interceptor already cleared localStorage
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    verify();

    // Listen for the event fired by api.js when a silent refresh fails
    const onForceLogout = () => {
      setUser(null);
      navigate('/login', { replace: true });
    };
    window.addEventListener('auth:logout', onForceLogout);
    return () => window.removeEventListener('auth:logout', onForceLogout);
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  // ── login ─────────────────────────────────────────────────────────────────

  const login = useCallback(async (email, password) => {
    const { data } = await authService.login({ email, password });
    const { user: loggedInUser, accessToken } = data.data;

    localStorage.setItem('accessToken', loggedInUser ? accessToken : '');
    localStorage.setItem('user', JSON.stringify(loggedInUser));
    setUser(loggedInUser);
    navigate('/', { replace: true });

    return data;
  }, [navigate]);

  // ── register ──────────────────────────────────────────────────────────────

  const register = useCallback(async (formData) => {
    const { data } = await authService.register(formData);
    const { user: newUser, accessToken } = data.data;

    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('user', JSON.stringify(newUser));
    setUser(newUser);
    navigate('/', { replace: true });

    return data;
  }, [navigate]);

  // ── logout ────────────────────────────────────────────────────────────────

  const logout = useCallback(async () => {
    try { await authService.logout(); } catch { /* best-effort */ }
    localStorage.removeItem('accessToken');
    localStorage.removeItem('user');
    setUser(null);
    navigate('/login', { replace: true });
  }, [navigate]);

  // ── Derived helpers ───────────────────────────────────────────────────────

  const isAuthenticated = Boolean(user);
  const isAdmin         = user?.role === 'admin';
  const isHR            = user?.role === 'hr' || isAdmin;

  return (
    <AuthContext.Provider value={{
      user,
      loading,
      isAuthenticated,
      isAdmin,
      isHR,
      login,
      register,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

// ─── Hook ─────────────────────────────────────────────────────────────────────

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
};
