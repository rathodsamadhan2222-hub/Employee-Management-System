// src/pages/EditEmployee.jsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Navbar  from '../components/Navbar';
import employeeService from '../services/employeeService';
import {
  ArrowLeft, Save, X, User, Mail, Phone, Calendar,
  Briefcase, ChevronRight, Loader2, AlertCircle, CheckCircle2,
} from 'lucide-react';

// ── Constants ─────────────────────────────────────────────────────────────────

const DEPARTMENTS      = ['Engineering','Product Design','Marketing','Sales','HR','Finance','Operations','Legal'];
const EMPLOYMENT_TYPES = ['Full-time Regular','Full-time Contract','Part-time','Internship'];
const STATUSES         = ['Active','Inactive','On Leave','Terminated'];

// ── Sub-components ────────────────────────────────────────────────────────────

const FormSection = ({ title, icon, children }) => (
  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-6">
    <div className="p-5 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
      <div className="p-2 bg-blue-600 rounded-lg text-white">{icon}</div>
      <h3 className="font-bold text-slate-900">{title}</h3>
    </div>
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
      {children}
    </div>
  </div>
);

const FieldError = ({ msg }) =>
  msg ? (
    <p className="flex items-center gap-1.5 text-xs font-semibold text-red-600 mt-1.5">
      <AlertCircle size={12} />{msg}
    </p>
  ) : null;

const inputCls = (err) =>
  `w-full px-4 py-3 bg-slate-50 border rounded-xl text-sm font-medium text-slate-900 outline-none
   focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all
   ${err ? 'border-red-400 bg-red-50' : 'border-slate-200'}`;

const InputField = ({ label, name, type = 'text', placeholder, required, icon: Icon, value, onChange, error }) => (
  <div className="space-y-1">
    <label className="text-sm font-bold text-slate-700">
      {label}{required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />}
      <input
        name={name} type={type} placeholder={placeholder} required={required}
        value={value} onChange={onChange}
        className={`${inputCls(error)} ${Icon ? 'pl-11' : ''}`}
      />
    </div>
    <FieldError msg={error} />
  </div>
);

const SelectField = ({ label, name, options, required, icon: Icon, value, onChange, error }) => (
  <div className="space-y-1">
    <label className="text-sm font-bold text-slate-700">
      {label}{required && <span className="text-red-500 ml-0.5">*</span>}
    </label>
    <div className="relative">
      {Icon && <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 z-10" size={17} />}
      <select
        name={name} required={required} value={value} onChange={onChange}
        className={`${inputCls(error)} appearance-none pr-10 ${Icon ? 'pl-11' : ''}`}
      >
        <option value="">Select {label}</option>
        {options.map((o) => <option key={o} value={o}>{o}</option>)}
      </select>
      <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 rotate-90 text-slate-400 pointer-events-none" size={16} />
    </div>
    <FieldError msg={error} />
  </div>
);

// ── Skeleton loader ───────────────────────────────────────────────────────────

const FormSkeleton = () => (
  <div className="animate-pulse space-y-6">
    {[...Array(2)].map((_, s) => (
      <div key={s} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-100 bg-slate-50/50">
          <div className="h-5 bg-slate-200 rounded w-48" />
        </div>
        <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="space-y-2">
              <div className="h-3 bg-slate-200 rounded w-24" />
              <div className="h-11 bg-slate-100 rounded-xl" />
            </div>
          ))}
        </div>
      </div>
    ))}
  </div>
);

// ── Page ──────────────────────────────────────────────────────────────────────

const EditEmployee = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [form,        setForm]        = useState(null);       // null = not yet loaded
  const [fieldErrors, setFieldErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [fetchError,  setFetchError]  = useState('');
  const [isFetching,  setIsFetching]  = useState(true);
  const [isSaving,    setIsSaving]    = useState(false);
  const [success,     setSuccess]     = useState(false);

  // ── Fetch existing employee data to pre-fill the form ──────────────────

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setIsFetching(true);
      setFetchError('');
      try {
        const { data } = await employeeService.getById(id);
        const emp = data.data;

        if (!cancelled) {
          // Format dates to YYYY-MM-DD for <input type="date">
          const toDateInput = (iso) => (iso ? new Date(iso).toISOString().split('T')[0] : '');

          setForm({
            fullName:       emp.fullName       || '',
            email:          emp.email          || '',
            mobileNumber:   emp.mobileNumber   || '',
            dateOfBirth:    toDateInput(emp.dateOfBirth),
            department:     emp.department     || '',
            designation:    emp.designation    || '',
            employmentType: emp.employmentType || 'Full-time Regular',
            joiningDate:    toDateInput(emp.joiningDate),
            status:         emp.status         || 'Active',
          });
        }
      } catch (err) {
        if (!cancelled) setFetchError(err.message || 'Failed to load employee.');
      } finally {
        if (!cancelled) setIsFetching(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [id]);

  // ── Form handlers ──────────────────────────────────────────────────────

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (fieldErrors[name]) setFieldErrors((p) => ({ ...p, [name]: '' }));
    if (serverError) setServerError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSaving(true);
    setFieldErrors({});
    setServerError('');

    try {
      await employeeService.update(id, form);
      setSuccess(true);
      setTimeout(() => navigate(`/employees/${id}`), 1400);
    } catch (err) {
      if (err.errors?.length) {
        const mapped = {};
        err.errors.forEach(({ field, message }) => { mapped[field] = message; });
        setFieldErrors(mapped);
        // Scroll to first field error
        requestAnimationFrame(() => {
          document.querySelector('[data-has-error="true"]')
            ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
        });
      } else {
        setServerError(err.message || 'Failed to update employee.');
      }
    } finally {
      setIsSaving(false);
    }
  };

  // ── Success flash ──────────────────────────────────────────────────────

  if (success) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center">
            <CheckCircle2 className="text-emerald-600" size={44} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Employee Updated!</h2>
          <p className="text-slate-500">Redirecting to profile…</p>
          <Loader2 className="animate-spin text-blue-600" size={22} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <Navbar title="Edit Employee" />

      <main className="ml-64 p-8 max-w-5xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate(`/employees/${id}`)}
              className="p-2 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} className="text-slate-600" />
            </button>
            <div>
              <p className="text-xs text-slate-400 font-medium">
                <Link to="/employees" className="hover:text-blue-600">Employees</Link>
                {' / '}
                <Link to={`/employees/${id}`} className="hover:text-blue-600">Profile</Link>
                {' / '}
                <span className="text-slate-600">Edit</span>
              </p>
              <h1 className="text-2xl font-bold text-slate-900 mt-0.5">Edit Employee</h1>
            </div>
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => navigate(`/employees/${id}`)}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <X size={16} /> Discard
            </button>
            <button
              form="edit-employee-form"
              type="submit"
              disabled={isSaving || isFetching}
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isSaving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
              {isSaving ? 'Saving…' : 'Save Changes'}
            </button>
          </div>
        </div>

        {/* Fetch error state */}
        {fetchError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
            <AlertCircle className="text-red-600 shrink-0" size={20} />
            <p className="text-sm font-semibold text-red-700">{fetchError}</p>
            <Link to="/employees" className="ml-auto text-sm font-bold text-red-700 hover:underline">
              ← Back to Employees
            </Link>
          </div>
        )}

        {/* Submit error banner */}
        {serverError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
            <AlertCircle className="text-red-600 shrink-0" size={20} />
            <p className="text-sm font-semibold text-red-700">{serverError}</p>
          </div>
        )}

        {isFetching ? (
          <FormSkeleton />
        ) : form ? (
          <form id="edit-employee-form" onSubmit={handleSubmit} noValidate>

            {/* Personal Information */}
            <FormSection title="Personal Information" icon={<User size={18} />}>
              <div data-has-error={!!fieldErrors.fullName}>
                <InputField
                  label="Full Name" name="fullName" placeholder="Jonathan Doe"
                  required icon={User}
                  value={form.fullName} onChange={handleChange}
                  error={fieldErrors.fullName}
                />
              </div>
              <div data-has-error={!!fieldErrors.email}>
                <InputField
                  label="Email Address" name="email" type="email" placeholder="j.doe@company.com"
                  required icon={Mail}
                  value={form.email} onChange={handleChange}
                  error={fieldErrors.email}
                />
              </div>
              <InputField
                label="Mobile Number" name="mobileNumber" type="tel" placeholder="+91 9876543210"
                icon={Phone}
                value={form.mobileNumber} onChange={handleChange}
                error={fieldErrors.mobileNumber}
              />
              <InputField
                label="Date of Birth" name="dateOfBirth" type="date"
                icon={Calendar}
                value={form.dateOfBirth} onChange={handleChange}
                error={fieldErrors.dateOfBirth}
              />
            </FormSection>

            {/* Job Details */}
            <FormSection title="Job Details" icon={<Briefcase size={18} />}>
              <div data-has-error={!!fieldErrors.department}>
                <SelectField
                  label="Department" name="department"
                  options={DEPARTMENTS} required icon={Briefcase}
                  value={form.department} onChange={handleChange}
                  error={fieldErrors.department}
                />
              </div>
              <div data-has-error={!!fieldErrors.designation}>
                <InputField
                  label="Designation" name="designation" placeholder="Senior Software Engineer"
                  required
                  value={form.designation} onChange={handleChange}
                  error={fieldErrors.designation}
                />
              </div>
              <SelectField
                label="Employment Type" name="employmentType"
                options={EMPLOYMENT_TYPES}
                value={form.employmentType} onChange={handleChange}
                error={fieldErrors.employmentType}
              />
              <div data-has-error={!!fieldErrors.joiningDate}>
                <InputField
                  label="Date of Joining" name="joiningDate" type="date"
                  required icon={Calendar}
                  value={form.joiningDate} onChange={handleChange}
                  error={fieldErrors.joiningDate}
                />
              </div>
            </FormSection>

            {/* Status */}
            <FormSection title="Employment Status" icon={<Briefcase size={18} />}>
              <SelectField
                label="Status" name="status"
                options={STATUSES} required
                value={form.status} onChange={handleChange}
                error={fieldErrors.status}
              />
            </FormSection>

            {/* Footer */}
            <div className="flex justify-end gap-4 border-t border-slate-200 pt-6 pb-12">
              <button
                type="button"
                onClick={() => navigate(`/employees/${id}`)}
                className="px-6 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSaving}
                className="px-8 py-3 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {isSaving && <Loader2 size={16} className="animate-spin" />}
                {isSaving ? 'Saving…' : 'Save Changes'}
              </button>
            </div>
          </form>
        ) : null}
      </main>
    </div>
  );
};

export default EditEmployee;
