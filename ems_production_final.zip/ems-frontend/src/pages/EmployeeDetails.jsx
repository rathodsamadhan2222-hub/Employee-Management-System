// src/pages/EmployeeDetails.jsx
import { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Navbar  from '../components/Navbar';
import employeeService from '../services/employeeService';
import { useAuth } from '../context/AuthContext';
import {
  ArrowLeft, Edit2, Trash2, Mail, Phone, Calendar, Briefcase,
  User, MapPin, Clock, BadgeCheck, Loader2, AlertCircle, Building2,
} from 'lucide-react';

// ── Helpers ───────────────────────────────────────────────────────────────────

const fmtDate = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
};

const getInitials = (name = '') =>
  name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

const yearsOfService = (joiningDate) => {
  if (!joiningDate) return null;
  const ms = Date.now() - new Date(joiningDate).getTime();
  const y  = Math.floor(ms / (1000 * 60 * 60 * 24 * 365.25));
  const m  = Math.floor((ms % (1000 * 60 * 60 * 24 * 365.25)) / (1000 * 60 * 60 * 24 * 30.44));
  if (y > 0) return `${y} yr${y !== 1 ? 's' : ''} ${m} mo`;
  return `${m} month${m !== 1 ? 's' : ''}`;
};

const statusColors = {
  Active:     'bg-emerald-100 text-emerald-700 border-emerald-200',
  Inactive:   'bg-slate-100   text-slate-600   border-slate-200',
  'On Leave': 'bg-amber-100   text-amber-700   border-amber-200',
  Terminated: 'bg-red-100     text-red-700     border-red-200',
};

// ── Delete confirmation modal ─────────────────────────────────────────────────

const DeleteModal = ({ name, onConfirm, onCancel, isDeleting }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-sm" onClick={onCancel} />
    <div className="relative bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm">
      <div className="flex items-center justify-center w-14 h-14 bg-red-100 rounded-2xl mx-auto mb-4">
        <Trash2 className="text-red-600" size={28} />
      </div>
      <h3 className="text-xl font-bold text-slate-900 text-center">Delete Employee</h3>
      <p className="text-slate-500 text-sm text-center mt-2">
        Are you sure you want to permanently delete{' '}
        <span className="font-bold text-slate-900">{name}</span>? This cannot be undone.
      </p>
      <div className="flex gap-3 mt-6">
        <button
          onClick={onCancel}
          disabled={isDeleting}
          className="flex-1 py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          disabled={isDeleting}
          className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isDeleting ? <Loader2 size={16} className="animate-spin" /> : null}
          {isDeleting ? 'Deleting…' : 'Delete'}
        </button>
      </div>
    </div>
  </div>
);

// ── InfoRow ───────────────────────────────────────────────────────────────────

const InfoRow = ({ icon: Icon, label, value }) => (
  <div className="flex items-start gap-4 py-4 border-b border-slate-100 last:border-0">
    <div className="p-2 bg-slate-100 rounded-lg shrink-0">
      <Icon size={18} className="text-slate-500" />
    </div>
    <div>
      <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{label}</p>
      <p className="text-sm font-semibold text-slate-900 mt-0.5">{value || '—'}</p>
    </div>
  </div>
);

// ── Page ──────────────────────────────────────────────────────────────────────

const EmployeeDetails = () => {
  const { id }     = useParams();
  const navigate   = useNavigate();
  const { isAdmin, isHR } = useAuth();

  const [employee,  setEmployee]  = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState('');
  const [showDelete,setShowDelete]= useState(false);
  const [isDeleting,setIsDeleting]= useState(false);

  // ── Fetch employee on mount ────────────────────────────────────────────

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      setLoading(true);
      setError('');
      try {
        const { data } = await employeeService.getById(id);
        if (!cancelled) setEmployee(data.data);
      } catch (err) {
        if (!cancelled) setError(err.message || 'Employee not found.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    load();
    return () => { cancelled = true; };
  }, [id]);

  // ── Delete ─────────────────────────────────────────────────────────────

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await employeeService.remove(id);
      navigate('/employees', { state: { toast: { type: 'success', message: `${employee.fullName} deleted.` } } });
    } catch (err) {
      setError(err.message || 'Failed to delete employee.');
      setShowDelete(false);
    } finally {
      setIsDeleting(false);
    }
  };

  // ── Loading state ──────────────────────────────────────────────────────

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Sidebar />
        <Navbar title="Employee Profile" />
        <main className="ml-64 p-8 flex items-center justify-center min-h-[60vh]">
          <div className="flex flex-col items-center gap-3">
            <Loader2 className="animate-spin text-blue-600" size={40} />
            <p className="text-slate-500 font-medium">Loading profile…</p>
          </div>
        </main>
      </div>
    );
  }

  // ── Error state ────────────────────────────────────────────────────────

  if (error || !employee) {
    return (
      <div className="min-h-screen bg-slate-50">
        <Sidebar />
        <Navbar title="Employee Profile" />
        <main className="ml-64 p-8 flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-20 h-20 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="text-red-600" size={40} />
            </div>
            <h2 className="text-xl font-bold text-slate-900">{error || 'Employee not found'}</h2>
            <Link to="/employees" className="mt-4 inline-flex items-center gap-2 text-blue-600 font-bold hover:underline">
              <ArrowLeft size={16} /> Back to Employees
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <Navbar title="Employee Profile" />

      <main className="ml-64 p-8">
        {/* Breadcrumb + actions */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/employees')}
              className="p-2 hover:bg-slate-200 rounded-lg transition-colors"
            >
              <ArrowLeft size={20} className="text-slate-600" />
            </button>
            <div>
              <p className="text-xs text-slate-400 font-medium">
                <Link to="/employees" className="hover:text-blue-600 transition-colors">Employees</Link>
                {' / '}
                <span className="text-slate-600">{employee.fullName}</span>
              </p>
              <h1 className="text-2xl font-bold text-slate-900 mt-0.5">Employee Profile</h1>
            </div>
          </div>

          <div className="flex items-center gap-3">
            {isHR && (
              <button
                onClick={() => navigate(`/employees/${id}/edit`)}
                className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors shadow-sm"
              >
                <Edit2 size={16} />
                Edit Profile
              </button>
            )}
            {isAdmin && (
              <button
                onClick={() => setShowDelete(true)}
                className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-xl text-sm font-bold hover:bg-red-700 transition-colors shadow-lg shadow-red-500/20"
              >
                <Trash2 size={16} />
                Delete
              </button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* ── Left: Avatar + status ─────────────────────────────────────── */}
          <div className="lg:col-span-1 space-y-6">

            {/* Avatar card */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-8 flex flex-col items-center text-center">
              <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center font-bold text-white text-3xl shadow-lg shadow-blue-500/20 mb-4">
                {getInitials(employee.fullName)}
              </div>
              <h2 className="text-xl font-bold text-slate-900">{employee.fullName}</h2>
              <p className="text-slate-500 font-medium mt-0.5">{employee.designation}</p>
              <p className="text-xs font-bold text-blue-600 mt-1 bg-blue-50 px-3 py-1 rounded-full">
                {employee.employeeId}
              </p>
              <span className={`mt-3 px-3 py-1 rounded-full text-xs font-bold border ${statusColors[employee.status] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                {employee.status}
              </span>
            </div>

            {/* Quick stats */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <h3 className="font-bold text-slate-900 mb-4 text-sm uppercase tracking-wider text-slate-500">At a Glance</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500 font-medium flex items-center gap-2"><Clock size={15}/> Tenure</span>
                  <span className="text-sm font-bold text-slate-900">{yearsOfService(employee.joiningDate) || '—'}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500 font-medium flex items-center gap-2"><Building2 size={15}/> Department</span>
                  <span className="text-sm font-bold text-slate-900">{employee.department}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-slate-500 font-medium flex items-center gap-2"><BadgeCheck size={15}/> Type</span>
                  <span className="text-sm font-bold text-slate-900">{employee.employmentType || '—'}</span>
                </div>
              </div>
            </div>

            {/* Added by */}
            {employee.createdBy && (
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                <h3 className="font-bold text-sm uppercase tracking-wider text-slate-500 mb-3">Record Info</h3>
                <p className="text-xs text-slate-500 font-medium">Added by</p>
                <p className="text-sm font-bold text-slate-900">{employee.createdBy.name}</p>
                <p className="text-xs text-slate-400 mt-2">Created {fmtDate(employee.createdAt)}</p>
                {employee.updatedBy && (
                  <>
                    <p className="text-xs text-slate-500 font-medium mt-3">Last updated by</p>
                    <p className="text-sm font-bold text-slate-900">{employee.updatedBy.name}</p>
                    <p className="text-xs text-slate-400 mt-1">{fmtDate(employee.updatedAt)}</p>
                  </>
                )}
              </div>
            )}
          </div>

          {/* ── Right: Details ────────────────────────────────────────────── */}
          <div className="lg:col-span-2 space-y-6">

            {/* Personal Information */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
                <div className="p-2 bg-blue-600 rounded-lg"><User size={18} className="text-white" /></div>
                <h3 className="font-bold text-slate-900">Personal Information</h3>
              </div>
              <div className="px-6 divide-y divide-slate-100">
                <InfoRow icon={User}     label="Full Name"     value={employee.fullName} />
                <InfoRow icon={Mail}     label="Email Address" value={employee.email} />
                <InfoRow icon={Phone}    label="Mobile Number" value={employee.mobileNumber} />
                <InfoRow icon={Calendar} label="Date of Birth" value={fmtDate(employee.dateOfBirth)} />
              </div>
            </div>

            {/* Job Details */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
                <div className="p-2 bg-violet-600 rounded-lg"><Briefcase size={18} className="text-white" /></div>
                <h3 className="font-bold text-slate-900">Job Details</h3>
              </div>
              <div className="px-6 divide-y divide-slate-100">
                <InfoRow icon={Building2}  label="Department"       value={employee.department} />
                <InfoRow icon={Briefcase}  label="Designation"      value={employee.designation} />
                <InfoRow icon={BadgeCheck} label="Employment Type"  value={employee.employmentType} />
                <InfoRow icon={Calendar}   label="Date of Joining"  value={fmtDate(employee.joiningDate)} />
                <InfoRow icon={Clock}      label="Years of Service" value={yearsOfService(employee.joiningDate)} />
              </div>
            </div>
          </div>
        </div>
      </main>

      {showDelete && (
        <DeleteModal
          name={employee.fullName}
          onConfirm={handleDelete}
          onCancel={() => setShowDelete(false)}
          isDeleting={isDeleting}
        />
      )}
    </div>
  );
};

export default EmployeeDetails;
