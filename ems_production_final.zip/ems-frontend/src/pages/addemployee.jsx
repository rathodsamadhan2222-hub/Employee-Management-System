// src/pages/addemployee.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Navbar  from '../components/Navbar';
import employeeService from '../services/employeeService';
import {
  User, Briefcase, Mail, Phone, Calendar,
  ChevronRight, Save, X, Info, Loader2, AlertCircle, CheckCircle2,
} from 'lucide-react';

// ── Constants ─────────────────────────────────────────────────────────────────

const DEPARTMENTS      = ['Engineering', 'Product Design', 'Marketing', 'Sales', 'HR', 'Finance', 'Operations', 'Legal'];
const EMPLOYMENT_TYPES = ['Full-time Regular', 'Full-time Contract', 'Part-time', 'Internship'];

// ── Initial form state ────────────────────────────────────────────────────────

const INITIAL_FORM = {
  fullName:       '',
  email:          '',
  mobileNumber:   '',
  dateOfBirth:    '',
  department:     '',
  designation:    '',
  joiningDate:    '',
  employmentType: 'Full-time Regular',
  status:         'Active',
};

// ── Sub-components ────────────────────────────────────────────────────────────

const FormSection = ({ title, icon, children }) => (
  <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-6">
    <div className="p-6 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
      <div className="p-2 bg-blue-600 rounded-lg text-white">{icon}</div>
      <h3 className="font-bold text-slate-900">{title}</h3>
    </div>
    <div className="p-6 grid grid-cols-1 md:grid-cols-2 gap-6">
      {children}
    </div>
  </div>
);

const InputField = ({ label, name, placeholder, type = 'text', icon: Icon, required, value, onChange, error }) => (
  <div className="space-y-1">
    <label className="text-sm font-bold text-slate-700 flex items-center gap-1">
      {label}
      {required && <span className="text-red-500">*</span>}
    </label>
    <div className="relative">
      {Icon && <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />}
      <input
        name={name}
        type={type}
        required={required}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className={`w-full ${Icon ? 'pl-11' : 'px-4'} pr-4 py-3 bg-slate-50 border rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all text-sm font-medium text-slate-900 ${
          error ? 'border-red-400 bg-red-50' : 'border-slate-200'
        }`}
      />
    </div>
    {error && (
      <p className="flex items-center gap-1.5 text-xs font-semibold text-red-600 mt-1">
        <AlertCircle size={12} />
        {error}
      </p>
    )}
  </div>
);

const SelectField = ({ label, name, options, icon: Icon, required, value, onChange, error }) => (
  <div className="space-y-1">
    <label className="text-sm font-bold text-slate-700 flex items-center gap-1">
      {label}
      {required && <span className="text-red-500">*</span>}
    </label>
    <div className="relative">
      {Icon && <Icon className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />}
      <select
        name={name}
        required={required}
        value={value}
        onChange={onChange}
        className={`w-full ${Icon ? 'pl-11' : 'px-4'} pr-10 py-3 bg-slate-50 border rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 outline-none transition-all text-sm font-medium text-slate-900 appearance-none ${
          error ? 'border-red-400 bg-red-50' : 'border-slate-200'
        }`}
      >
        <option value="">Select {label}</option>
        {options.map((opt) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
      <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 rotate-90 text-slate-400 pointer-events-none" size={16} />
    </div>
    {error && (
      <p className="flex items-center gap-1.5 text-xs font-semibold text-red-600 mt-1">
        <AlertCircle size={12} />
        {error}
      </p>
    )}
  </div>
);

// ── Page ──────────────────────────────────────────────────────────────────────

const AddEmployee = () => {
  const navigate = useNavigate();

  const [form,        setForm]        = useState(INITIAL_FORM);
  const [fieldErrors, setFieldErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [isLoading,   setIsLoading]   = useState(false);
  const [success,     setSuccess]     = useState(false);

  // ── Handlers ────────────────────────────────────────────────────────────

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (fieldErrors[name]) setFieldErrors((p) => ({ ...p, [name]: '' }));
    if (serverError)        setServerError('');
  };

  const handleClear = () => {
    setForm(INITIAL_FORM);
    setFieldErrors({});
    setServerError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setFieldErrors({});
    setServerError('');

    try {
      await employeeService.create(form);
      setSuccess(true);
      // Brief success flash then navigate to employees list
      setTimeout(() => navigate('/employees'), 1500);
    } catch (err) {
      if (err.errors?.length) {
        const mapped = {};
        err.errors.forEach(({ field, message }) => { mapped[field] = message; });
        setFieldErrors(mapped);
        // Scroll to first error
        const firstField = document.querySelector('[data-error="true"]');
        firstField?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else {
        setServerError(err.message || 'Failed to add employee. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // ── Success overlay ──────────────────────────────────────────────────────

  if (success) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center">
            <CheckCircle2 className="text-emerald-600" size={44} />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Employee Added!</h2>
          <p className="text-slate-500">Redirecting to the employees list…</p>
          <Loader2 className="animate-spin text-blue-600" size={24} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <Navbar title="Onboard New Employee" />

      <main className="ml-64 p-8 max-w-5xl mx-auto">
        {/* Page header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Add New Employee</h1>
            <p className="text-slate-500 mt-1">Register a new member to the organisation ecosystem.</p>
          </div>
          <div className="flex gap-3">
            <button
              type="button"
              onClick={() => navigate('/employees')}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              <X size={18} />
              Discard
            </button>
            <button
              form="add-employee-form"
              type="submit"
              disabled={isLoading}
              className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? <Loader2 size={18} className="animate-spin" /> : <Save size={18} />}
              {isLoading ? 'Saving…' : 'Save Employee'}
            </button>
          </div>
        </div>

        {/* Global server error */}
        {serverError && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
            <AlertCircle className="text-red-600 shrink-0" size={20} />
            <p className="text-sm font-semibold text-red-700">{serverError}</p>
          </div>
        )}

        <form id="add-employee-form" onSubmit={handleSubmit} noValidate className="pb-12">

          {/* Personal Information */}
          <FormSection title="Personal Information" icon={<User size={20} />}>
            <div data-error={!!fieldErrors.fullName}>
              <InputField
                label="Full Name" name="fullName" placeholder="e.g. Jonathan Doe"
                icon={User} required
                value={form.fullName} onChange={handleChange}
                error={fieldErrors.fullName}
              />
            </div>
            <div data-error={!!fieldErrors.email}>
              <InputField
                label="Email Address" name="email" placeholder="j.doe@enterprise.com"
                type="email" icon={Mail} required
                value={form.email} onChange={handleChange}
                error={fieldErrors.email}
              />
            </div>
            <InputField
              label="Phone Number" name="mobileNumber" placeholder="+91 9876543210"
              type="tel" icon={Phone}
              value={form.mobileNumber} onChange={handleChange}
              error={fieldErrors.mobileNumber}
            />
            <InputField
              label="Date of Birth" name="dateOfBirth" placeholder="mm/dd/yyyy"
              type="date" icon={Calendar}
              value={form.dateOfBirth} onChange={handleChange}
              error={fieldErrors.dateOfBirth}
            />
          </FormSection>

          {/* Job Details */}
          <FormSection title="Job Details" icon={<Briefcase size={20} />}>
            <div data-error={!!fieldErrors.department}>
              <SelectField
                label="Department" name="department"
                options={DEPARTMENTS} icon={Briefcase} required
                value={form.department} onChange={handleChange}
                error={fieldErrors.department}
              />
            </div>
            <div data-error={!!fieldErrors.designation}>
              <InputField
                label="Designation" name="designation" placeholder="e.g. Senior Software Engineer"
                required
                value={form.designation} onChange={handleChange}
                error={fieldErrors.designation}
              />
            </div>
            <div data-error={!!fieldErrors.joiningDate}>
              <InputField
                label="Date of Joining" name="joiningDate" placeholder="mm/dd/yyyy"
                type="date" icon={Calendar} required
                value={form.joiningDate} onChange={handleChange}
                error={fieldErrors.joiningDate}
              />
            </div>
            <SelectField
              label="Employment Type" name="employmentType"
              options={EMPLOYMENT_TYPES}
              value={form.employmentType} onChange={handleChange}
              error={fieldErrors.employmentType}
            />
          </FormSection>

          {/* Compliance notice */}
          <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl mb-8 flex gap-4">
            <div className="p-2 bg-blue-100 rounded-lg text-blue-600 h-fit">
              <Info size={24} />
            </div>
            <div>
              <h4 className="font-bold text-blue-900">Compliance Verified</h4>
              <p className="text-blue-700 text-sm mt-1 leading-relaxed">
                Our onboarding protocol automatically ensures all regional labour laws and enterprise
                policies are met during this registration process. An Employee ID will be generated
                automatically upon submission.
              </p>
            </div>
          </div>

          {/* Footer actions */}
          <div className="flex items-center justify-end gap-4 border-t border-slate-200 pt-8">
            <button
              type="button"
              onClick={handleClear}
              className="px-6 py-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-600 hover:bg-slate-50 transition-colors"
            >
              Clear Form
            </button>
            <button
              type="submit"
              disabled={isLoading}
              className="px-8 py-3 bg-blue-600 text-white rounded-xl text-sm font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20 flex items-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
            >
              {isLoading ? <Loader2 size={18} className="animate-spin" /> : null}
              {isLoading ? 'Submitting…' : 'Submit Details'}
            </button>
          </div>
        </form>
      </main>
    </div>
  );
};

export default AddEmployee;
