// src/pages/dashboard.jsx
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../components/Sidebar';
import Navbar  from '../components/Navbar';
import { useAuth } from '../context/AuthContext';
import { dashboardService } from '../services/employeeService';
import {
  Users, UserCheck, Briefcase, UserPlus, TrendingUp,
  Download, RefreshCw, Loader2, AlertCircle, Calendar,
  ArrowUpRight,
} from 'lucide-react';

const fmtDate = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};
const getInitials = (name = '') =>
  name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();
const statusColors = {
  Active:     'bg-emerald-100 text-emerald-700',
  Inactive:   'bg-slate-100   text-slate-600',
  'On Leave': 'bg-amber-100   text-amber-700',
  Terminated: 'bg-red-100     text-red-700',
};

const StatCardSkeleton = () => (
  <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm animate-pulse">
    <div className="flex items-center justify-between mb-4">
      <div className="w-12 h-12 rounded-xl bg-slate-100" />
      <div className="w-14 h-5 rounded-full bg-slate-100" />
    </div>
    <div className="h-3 bg-slate-100 rounded w-32 mb-3" />
    <div className="h-9 bg-slate-100 rounded w-20" />
  </div>
);

const TableRowSkeleton = () => (
  <tr className="animate-pulse">
    <td className="px-6 py-4">
      <div className="flex items-center gap-3">
        <div className="w-9 h-9 rounded-full bg-slate-100 shrink-0" />
        <div className="space-y-1.5">
          <div className="h-3 bg-slate-100 rounded w-28" />
          <div className="h-2.5 bg-slate-100 rounded w-36" />
        </div>
      </div>
    </td>
    <td className="px-6 py-4"><div className="h-3 bg-slate-100 rounded w-24" /></td>
    <td className="px-6 py-4"><div className="h-5 bg-slate-100 rounded-full w-14" /></td>
    <td className="px-6 py-4"><div className="h-3 bg-slate-100 rounded w-20" /></td>
  </tr>
);

const StatCard = ({ title, value, icon, iconBg, iconColor, trend, trendLabel, loading }) => {
  if (loading) return <StatCardSkeleton />;
  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-xl ${iconBg}`}>
          <div className={iconColor}>{icon}</div>
        </div>
        {trend !== undefined && (
          <span className={`text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
            trend >= 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
          }`}>
            <TrendingUp size={11} />
            {trend >= 0 ? '+' : ''}{trend}%
          </span>
        )}
      </div>
      <p className="text-sm font-medium text-slate-500">{title}</p>
      <p className="text-3xl font-bold text-slate-900 mt-1 tabular-nums">
        {value?.toLocaleString() ?? '—'}
      </p>
      {trendLabel && <p className="text-xs text-slate-400 mt-1.5 font-medium">{trendLabel}</p>}
    </div>
  );
};

const MiniBarChart = ({ data }) => {
  if (!data?.length) return null;
  const max = Math.max(...data.map((d) => d.count), 1);
  return (
    <div className="flex items-end gap-1.5 h-20">
      {data.map((d, i) => (
        <div key={i} className="flex-1 flex flex-col items-center gap-1 group">
          <div
            className="w-full bg-blue-500 rounded-t-sm group-hover:bg-blue-600 transition-colors relative"
            style={{ height: `${Math.max((d.count / max) * 100, 4)}%` }}
          >
            <div className="absolute -top-7 left-1/2 -translate-x-1/2 bg-slate-800 text-white text-[10px] font-bold px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
              {d.count}
            </div>
          </div>
          <span className="text-[9px] font-bold text-slate-400 uppercase">{d.month}</span>
        </div>
      ))}
    </div>
  );
};

const DeptBar = ({ department, total, active, maxTotal }) => {
  const pct = maxTotal > 0 ? Math.round((total / maxTotal) * 100) : 0;
  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <span className="text-sm font-semibold text-slate-700 truncate max-w-[60%]">{department}</span>
        <span className="text-xs font-bold text-slate-500">{active}/{total}</span>
      </div>
      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
        <div className="h-full bg-blue-500 rounded-full transition-all duration-700" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
};

const Dashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats,       setStats]       = useState(null);
  const [loading,     setLoading]     = useState(true);
  const [error,       setError]       = useState('');
  const [lastUpdated, setLastUpdated] = useState(null);

  const loadStats = async () => {
    setLoading(true);
    setError('');
    try {
      const { data } = await dashboardService.getStats();
      setStats(data.data);
      setLastUpdated(new Date());
    } catch (err) {
      setError(err.message || 'Failed to load dashboard data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadStats(); }, []); // eslint-disable-line

  const maxDept = Math.max(...(stats?.departmentBreakdown?.map((d) => d.total) || [0]));

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <Navbar title="Organization Overview" />
      <main className="ml-64 p-8">

        {/* Header */}
        <div className="flex items-start justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Welcome back, {user?.name?.split(' ')[0] ?? 'Admin'} 👋
            </h1>
            <p className="text-slate-500 mt-1 text-sm">
              Here's what's happening with your workforce today.
              {lastUpdated && (
                <span className="text-slate-400 ml-2">
                  · Updated {lastUpdated.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              )}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={loadStats} disabled={loading}
              className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 transition-all shadow-sm disabled:opacity-50">
              <RefreshCw size={15} className={loading ? 'animate-spin' : ''} /> Refresh
            </button>
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-xl text-sm font-semibold text-slate-600 hover:bg-slate-50 shadow-sm">
              <Download size={15} /> Export
            </button>
            <button onClick={() => navigate('/add-employee')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 shadow-lg shadow-blue-500/20">
              <UserPlus size={15} /> Add Employee
            </button>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
            <AlertCircle className="text-red-600 shrink-0" size={20} />
            <p className="text-sm font-semibold text-red-700">{error}</p>
            <button onClick={loadStats} className="ml-auto text-sm font-bold text-red-700 hover:underline flex items-center gap-1">
              <RefreshCw size={13} /> Retry
            </button>
          </div>
        )}

        {/* Stat cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
          <StatCard loading={loading} title="Total Employees"  value={stats?.totalEmployees}
            icon={<Users size={22}/>} iconBg="bg-blue-50"    iconColor="text-blue-600"    trend={12} trendLabel="vs last month"/>
          <StatCard loading={loading} title="Active Employees" value={stats?.activeEmployees}
            icon={<UserCheck size={22}/>} iconBg="bg-emerald-50" iconColor="text-emerald-600" trend={5}
            trendLabel={stats ? `${Math.round((stats.activeEmployees/Math.max(stats.totalEmployees,1))*100)}% of total` : ''}/>
          <StatCard loading={loading} title="Departments"      value={stats?.totalDepartments}
            icon={<Briefcase size={22}/>} iconBg="bg-violet-50"  iconColor="text-violet-600"  trendLabel="Active departments"/>
          <StatCard loading={loading} title="New This Month"   value={stats?.newThisMonth}
            icon={<UserPlus size={22}/>}  iconBg="bg-amber-50"   iconColor="text-amber-600"   trend={stats?.newThisMonth > 0 ? 8 : 0} trendLabel="Onboarded this month"/>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">

          {/* Recent employees */}
          <div className="xl:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="px-6 py-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-slate-900">Recent Employees</h3>
                <p className="text-xs text-slate-400 mt-0.5">Latest additions to the organisation</p>
              </div>
              <button onClick={() => navigate('/employees')}
                className="flex items-center gap-1 text-sm font-bold text-blue-600 hover:underline">
                View All <ArrowUpRight size={14}/>
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead className="bg-slate-50 border-b border-slate-100">
                  <tr>
                    {['Employee','Department','Status','Joined'].map((h) => (
                      <th key={h} className="px-6 py-3.5 text-xs font-bold text-slate-400 uppercase tracking-wider">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {loading
                    ? [...Array(5)].map((_,i) => <TableRowSkeleton key={i}/>)
                    : !stats?.recentEmployees?.length
                      ? (
                        <tr><td colSpan={4} className="px-6 py-12 text-center">
                          <div className="flex flex-col items-center gap-2">
                            <Users className="text-slate-300" size={36}/>
                            <p className="text-slate-400 font-medium text-sm">No employees yet</p>
                            <button onClick={() => navigate('/add-employee')} className="text-sm font-bold text-blue-600 hover:underline">Add the first one →</button>
                          </div>
                        </td></tr>
                      )
                      : stats.recentEmployees.map((emp) => (
                          <tr key={emp._id} onClick={() => navigate(`/employees/${emp._id}`)}
                            className="hover:bg-slate-50 transition-colors cursor-pointer group">
                            <td className="px-6 py-4">
                              <div className="flex items-center gap-3">
                                <div className="w-9 h-9 rounded-full bg-blue-100 flex items-center justify-center font-bold text-blue-600 text-xs shrink-0">
                                  {getInitials(emp.fullName)}
                                </div>
                                <div>
                                  <p className="text-sm font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">{emp.fullName}</p>
                                  <p className="text-xs text-slate-400">{emp.email}</p>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4">
                              <p className="text-sm text-slate-600 font-medium">{emp.department}</p>
                              <p className="text-xs text-slate-400">{emp.designation}</p>
                            </td>
                            <td className="px-6 py-4">
                              <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${statusColors[emp.status]||'bg-slate-100 text-slate-600'}`}>
                                {emp.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-500 font-medium">{fmtDate(emp.joiningDate)}</td>
                          </tr>
                        ))
                  }
                </tbody>
              </table>
            </div>
          </div>

          {/* Right column */}
          <div className="space-y-6">

            {/* Monthly growth */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-bold text-slate-900">Monthly Growth</h3>
                  <p className="text-xs text-slate-400 mt-0.5">New hires · Last 6 months</p>
                </div>
                <div className="p-2 bg-blue-50 rounded-lg"><TrendingUp className="text-blue-600" size={18}/></div>
              </div>
              {loading
                ? <div className="h-20 bg-slate-100 rounded-lg animate-pulse"/>
                : <MiniBarChart data={stats?.monthlyGrowth}/>
              }
              {!loading && stats?.newThisMonth !== undefined && (
                <p className="text-xs text-slate-500 mt-3 font-medium text-center">
                  <span className="font-bold text-blue-600">{stats.newThisMonth}</span> new hire{stats.newThisMonth !== 1 ? 's' : ''} this month
                </p>
              )}
            </div>

            {/* Department breakdown */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <div className="flex items-center justify-between mb-5">
                <div>
                  <h3 className="font-bold text-slate-900">By Department</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Active / Total headcount</p>
                </div>
                <div className="p-2 bg-violet-50 rounded-lg"><Briefcase className="text-violet-600" size={18}/></div>
              </div>
              {loading
                ? <div className="space-y-4 animate-pulse">{[...Array(4)].map((_,i)=>(
                    <div key={i} className="space-y-1.5">
                      <div className="h-3 bg-slate-100 rounded w-32"/>
                      <div className="h-2 bg-slate-100 rounded-full"/>
                    </div>))}</div>
                : stats?.departmentBreakdown?.length
                  ? <div className="space-y-4">{stats.departmentBreakdown.slice(0,6).map((d)=>(
                      <DeptBar key={d.department} {...d} maxTotal={maxDept}/>))}</div>
                  : <p className="text-sm text-slate-400 text-center py-4">No department data yet</p>
              }
            </div>

            {/* Status distribution */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
              <h3 className="font-bold text-slate-900 mb-4">Status Distribution</h3>
              {loading
                ? <div className="space-y-3 animate-pulse">{[...Array(3)].map((_,i)=>(
                    <div key={i} className="flex items-center justify-between">
                      <div className="h-3 bg-slate-100 rounded w-20"/>
                      <div className="h-5 bg-slate-100 rounded-full w-10"/>
                    </div>))}</div>
                : <div className="space-y-3">
                    {(stats?.statusDistribution||[]).map((s)=>(
                      <div key={s.status} className="flex items-center justify-between">
                        <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${statusColors[s.status]||'bg-slate-100 text-slate-600'}`}>
                          {s.status}
                        </span>
                        <div className="flex items-center gap-2">
                          <div className="h-1.5 w-20 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-blue-500 rounded-full"
                              style={{width:`${Math.round((s.count/Math.max(stats.totalEmployees,1))*100)}%`}}/>
                          </div>
                          <span className="text-xs font-bold text-slate-600 tabular-nums w-6 text-right">{s.count}</span>
                        </div>
                      </div>))}
                  </div>
              }
            </div>

            {/* Quick actions */}
            <div className="bg-gradient-to-br from-blue-600 to-blue-700 p-6 rounded-2xl text-white shadow-lg shadow-blue-500/20">
              <div className="flex items-center gap-2 mb-4">
                <Calendar size={20}/><h3 className="font-bold">Quick Actions</h3>
              </div>
              <div className="space-y-2">
                <button onClick={() => navigate('/add-employee')}
                  className="w-full py-2.5 bg-white/20 hover:bg-white/30 rounded-xl text-sm font-semibold transition-colors text-left px-4">
                  + Add New Employee
                </button>
                <button onClick={() => navigate('/employees')}
                  className="w-full py-2.5 bg-white/20 hover:bg-white/30 rounded-xl text-sm font-semibold transition-colors text-left px-4">
                  View All Employees
                </button>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
