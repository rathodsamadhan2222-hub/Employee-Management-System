// src/pages/employees.jsx
import { useState, useEffect, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Sidebar  from '../components/Sidebar';
import Navbar   from '../components/Navbar';
import { useAuth } from '../context/AuthContext';
import employeeService from '../services/employeeService';
import {
  Search, Filter, Eye, Edit2, Trash2, Plus,
  Download, ChevronLeft, ChevronRight, X,
  Loader2, AlertCircle, CheckCircle2,
} from 'lucide-react';

// ── Constants ─────────────────────────────────────────────────────────────────

const DEPARTMENTS = ['Engineering', 'Product Design', 'Marketing', 'Sales', 'HR', 'Finance', 'Operations', 'Legal'];
const STATUSES    = ['Active', 'Inactive', 'On Leave', 'Terminated'];
const SORT_OPTS   = [
  { label: 'Date Added',    value: 'createdAt'   },
  { label: 'Joining Date',  value: 'joiningDate' },
  { label: 'Name',          value: 'fullName'    },
  { label: 'Department',    value: 'department'  },
];

// ── Helpers ───────────────────────────────────────────────────────────────────

const getInitials = (name = '') =>
  name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase();

const fmtDate = (iso) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
};

// ── Skeleton row ──────────────────────────────────────────────────────────────

const SkeletonRow = () => (
  <tr className="animate-pulse">
    {[140, 180, 120, 100, 80, 80].map((w, i) => (
      <td key={i} className="px-6 py-4">
        <div className={`h-4 bg-slate-100 rounded`} style={{ width: w }} />
      </td>
    ))}
  </tr>
);

// ── Delete confirm modal ──────────────────────────────────────────────────────

const DeleteModal = ({ employee, onConfirm, onCancel, isDeleting }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
    <div className="absolute inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onCancel} />
    <div className="relative bg-white rounded-2xl shadow-2xl p-8 w-full max-w-sm">
      <div className="flex items-center justify-center w-14 h-14 bg-red-100 rounded-2xl mx-auto mb-4">
        <Trash2 className="text-red-600" size={28} />
      </div>
      <h3 className="text-xl font-bold text-slate-900 text-center">Delete Employee</h3>
      <p className="text-slate-500 text-sm text-center mt-2 leading-relaxed">
        Are you sure you want to delete <span className="font-bold text-slate-900">{employee?.fullName}</span>?
        This action cannot be undone.
      </p>
      <div className="flex gap-3 mt-6">
        <button
          onClick={onCancel}
          disabled={isDeleting}
          className="flex-1 py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors disabled:opacity-50"
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          disabled={isDeleting}
          className="flex-1 py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {isDeleting ? <Loader2 size={18} className="animate-spin" /> : 'Delete'}
        </button>
      </div>
    </div>
  </div>
);

// ── Toast ─────────────────────────────────────────────────────────────────────

const Toast = ({ toast }) => {
  if (!toast) return null;
  const isSuccess = toast.type === 'success';
  return (
    <div className={`fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-4 rounded-2xl shadow-2xl font-semibold text-sm text-white transition-all ${isSuccess ? 'bg-emerald-600' : 'bg-red-600'}`}>
      {isSuccess ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
      {toast.message}
    </div>
  );
};

// ── Page ──────────────────────────────────────────────────────────────────────

const Employees = () => {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();

  // ── Data state ─────────────────────────────────────────────────────────

  const [employees, setEmployees] = useState([]);
  const [meta,      setMeta]      = useState(null);
  const [loading,   setLoading]   = useState(true);
  const [error,     setError]     = useState('');

  // ── Filter / pagination state ──────────────────────────────────────────

  const [search,     setSearch]     = useState('');
  const [department, setDepartment] = useState('');
  const [status,     setStatus]     = useState('');
  const [sort,       setSort]       = useState('createdAt');
  const [order,      setOrder]      = useState('desc');
  const [page,       setPage]       = useState(1);
  const [limit,      setLimit]      = useState(10);
  const [showFilter, setShowFilter] = useState(false);

  // ── UI state ───────────────────────────────────────────────────────────

  const [toDelete,   setToDelete]   = useState(null);   // employee object pending delete
  const [isDeleting, setIsDeleting] = useState(false);
  const [toast,      setToast]      = useState(null);

  const debounceRef = useRef(null);

  // ── Show toast then auto-hide ──────────────────────────────────────────

  const showToast = useCallback((message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  }, []);

  // ── Fetch employees ────────────────────────────────────────────────────

  const fetchEmployees = useCallback(async (params) => {
    setLoading(true);
    setError('');
    try {
      const { data } = await employeeService.getAll(params);
      setEmployees(data.data  || []);
      setMeta(data.meta       || null);
    } catch (err) {
      setError(err.message || 'Failed to fetch employees.');
    } finally {
      setLoading(false);
    }
  }, []);

  // Re-fetch whenever any filter / page changes
  useEffect(() => {
    fetchEmployees({ page, limit, search, department, status, sort, order });
  }, [page, limit, search, department, status, sort, order, fetchEmployees]);

  // ── Search — debounce 400 ms ───────────────────────────────────────────

  const handleSearchChange = (e) => {
    const val = e.target.value;
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setSearch(val);
      setPage(1);
    }, 400);
  };

  // ── Filter helpers ─────────────────────────────────────────────────────

  const setFilterValue = (setter) => (e) => {
    setter(e.target.value);
    setPage(1);
  };

  const clearFilters = () => {
    setSearch('');
    setDepartment('');
    setStatus('');
    setSort('createdAt');
    setOrder('desc');
    setPage(1);
  };

  const hasActiveFilters = search || department || status || sort !== 'createdAt' || order !== 'desc';

  // ── Sort toggle ────────────────────────────────────────────────────────

  const handleSortChange = (field) => {
    if (sort === field) {
      setOrder((o) => (o === 'asc' ? 'desc' : 'asc'));
    } else {
      setSort(field);
      setOrder('desc');
    }
    setPage(1);
  };

  // ── Delete ─────────────────────────────────────────────────────────────

  const confirmDelete = async () => {
    if (!toDelete) return;
    setIsDeleting(true);
    try {
      await employeeService.remove(toDelete._id);
      showToast(`${toDelete.fullName} has been deleted.`);
      fetchEmployees({ page, limit, search, department, status, sort, order });
    } catch (err) {
      showToast(err.message || 'Failed to delete employee.', 'error');
    } finally {
      setIsDeleting(false);
      setToDelete(null);
    }
  };

  // ── Pagination helpers ─────────────────────────────────────────────────

  const totalPages  = meta?.totalPages || 1;
  const pageNumbers = Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
    if (totalPages <= 5) return i + 1;
    if (page <= 3)       return i + 1;
    if (page >= totalPages - 2) return totalPages - 4 + i;
    return page - 2 + i;
  });

  return (
    <div className="min-h-screen bg-slate-50">
      <Sidebar />
      <Navbar title="Team Directory" />

      <main className="ml-64 p-8">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Employees</h1>
            <p className="text-slate-500">Manage your organisation's talent and oversee department growth.</p>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-semibold text-slate-700 hover:bg-slate-50 transition-all shadow-sm">
              <Download size={18} />
              Export
            </button>
            <button
              onClick={() => navigate('/add-employee')}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-semibold hover:bg-blue-700 transition-all shadow-lg shadow-blue-500/20"
            >
              <Plus size={18} />
              Add New Employee
            </button>
          </div>
        </div>

        {/* Error banner */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center gap-3">
            <AlertCircle className="text-red-600 shrink-0" size={20} />
            <p className="text-sm font-semibold text-red-700">{error}</p>
            <button onClick={() => fetchEmployees({ page, limit, search, department, status, sort, order })} className="ml-auto text-sm font-bold text-red-700 hover:underline">
              Retry
            </button>
          </div>
        )}

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden mb-8">
          {/* Toolbar */}
          <div className="p-4 border-b border-slate-100 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-slate-50/50">
            <div className="flex items-center gap-3 w-full md:w-auto flex-wrap">
              {/* Search */}
              <div className="relative w-full md:w-80">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input
                  type="text"
                  placeholder="Filter by name, email or ID..."
                  defaultValue={search}
                  onChange={handleSearchChange}
                  className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none transition-all"
                />
              </div>

              {/* Filter toggle */}
              <button
                onClick={() => setShowFilter((s) => !s)}
                className={`flex items-center gap-2 px-3 py-2 border rounded-lg text-sm font-medium transition-colors ${showFilter ? 'bg-blue-600 text-white border-blue-600' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}`}
              >
                <Filter size={16} />
                Filters
                {hasActiveFilters && !showFilter && (
                  <span className="w-2 h-2 rounded-full bg-blue-600 border-2 border-white absolute" />
                )}
              </button>

              {/* Active filter pills */}
              {department && (
                <span className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 bg-blue-100 text-blue-700 rounded-full">
                  {department}
                  <button onClick={() => { setDepartment(''); setPage(1); }}><X size={12} /></button>
                </span>
              )}
              {status && (
                <span className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 bg-blue-100 text-blue-700 rounded-full">
                  {status}
                  <button onClick={() => { setStatus(''); setPage(1); }}><X size={12} /></button>
                </span>
              )}
              {hasActiveFilters && (
                <button onClick={clearFilters} className="text-xs font-bold text-slate-500 hover:text-red-600 transition-colors">
                  Clear all
                </button>
              )}
            </div>

            {/* Sort + count */}
            <div className="flex items-center gap-3 shrink-0">
              <select
                value={sort}
                onChange={(e) => { setSort(e.target.value); setPage(1); }}
                className="text-xs font-semibold bg-white border border-slate-200 rounded-lg px-3 py-2 outline-none text-slate-600"
              >
                {SORT_OPTS.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
              </select>
              <button
                onClick={() => { setOrder((o) => o === 'asc' ? 'desc' : 'asc'); setPage(1); }}
                className="text-xs font-bold text-slate-600 bg-white border border-slate-200 rounded-lg px-3 py-2 hover:bg-slate-50"
              >
                {order === 'asc' ? '↑ Asc' : '↓ Desc'}
              </button>
              <span className="text-sm text-slate-500 font-medium whitespace-nowrap">
                {meta ? `${((page - 1) * limit) + 1}–${Math.min(page * limit, meta.total)} of ${meta.total.toLocaleString()}` : '…'}
              </span>
            </div>
          </div>

          {/* Expandable filters */}
          {showFilter && (
            <div className="px-4 py-4 border-b border-slate-100 bg-slate-50/80 flex flex-wrap gap-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Department</label>
                <select
                  value={department}
                  onChange={setFilterValue(setDepartment)}
                  className="block w-48 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none font-medium text-slate-700"
                >
                  <option value="">All Departments</option>
                  {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase tracking-wider">Status</label>
                <select
                  value={status}
                  onChange={setFilterValue(setStatus)}
                  className="block w-40 px-3 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none font-medium text-slate-700"
                >
                  <option value="">All Statuses</option>
                  {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
            </div>
          )}

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 border-b border-slate-100">
                <tr>
                  {[
                    { label: 'Full Name',     field: 'fullName'    },
                    { label: 'Contact',       field: null          },
                    { label: 'Department',    field: 'department'  },
                    { label: 'Joining Date',  field: 'joiningDate' },
                    { label: 'Status',        field: 'status'      },
                    { label: 'Actions',       field: null,  right: true },
                  ].map(({ label, field, right }) => (
                    <th
                      key={label}
                      onClick={() => field && handleSortChange(field)}
                      className={`px-6 py-4 text-xs font-bold text-slate-500 uppercase tracking-wider ${field ? 'cursor-pointer hover:text-blue-600 select-none' : ''} ${right ? 'text-right' : ''}`}
                    >
                      {label}
                      {field && sort === field && (
                        <span className="ml-1">{order === 'asc' ? '↑' : '↓'}</span>
                      )}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {loading
                  ? [...Array(limit > 5 ? 5 : limit)].map((_, i) => <SkeletonRow key={i} />)
                  : employees.length === 0
                    ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-16 text-center">
                          <div className="flex flex-col items-center gap-3">
                            <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center">
                              <Search className="text-slate-400" size={28} />
                            </div>
                            <p className="font-bold text-slate-700">No employees found</p>
                            <p className="text-sm text-slate-500">Try adjusting your search or filter criteria.</p>
                            {hasActiveFilters && (
                              <button onClick={clearFilters} className="text-sm font-bold text-blue-600 hover:underline">Clear filters</button>
                            )}
                          </div>
                        </td>
                      </tr>
                    )
                    : employees.map((emp) => (
                        <tr key={emp._id} className="hover:bg-slate-50/50 transition-colors group">
                          {/* Name + ID */}
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center gap-3">
                              <div className="w-10 h-10 rounded-full bg-blue-100 border border-blue-200 flex items-center justify-center font-bold text-blue-600 text-sm shrink-0">
                                {getInitials(emp.fullName)}
                              </div>
                              <div>
                                <p className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors">{emp.fullName}</p>
                                <p className="text-xs text-slate-500 font-medium">{emp.employeeId}</p>
                              </div>
                            </div>
                          </td>
                          {/* Contact */}
                          <td className="px-6 py-4">
                            <p className="text-sm text-slate-600 font-medium">{emp.email}</p>
                            <p className="text-xs text-slate-400">{emp.mobileNumber || '—'}</p>
                          </td>
                          {/* Department */}
                          <td className="px-6 py-4">
                            <p className="text-sm text-slate-600 font-semibold">{emp.department}</p>
                            <p className="text-xs text-slate-500 font-medium">{emp.designation}</p>
                          </td>
                          {/* Joining Date */}
                          <td className="px-6 py-4 text-sm text-slate-600 font-medium">
                            {fmtDate(emp.joiningDate)}
                          </td>
                          {/* Status */}
                          <td className="px-6 py-4">
                            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                              emp.status === 'Active'    ? 'bg-emerald-100 text-emerald-700' :
                              emp.status === 'On Leave'  ? 'bg-amber-100  text-amber-700'  :
                              emp.status === 'Terminated'? 'bg-red-100    text-red-700'    :
                                                           'bg-slate-100  text-slate-600'
                            }`}>
                              {emp.status}
                            </span>
                          </td>
                          {/* Actions */}
                          <td className="px-6 py-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <button
                                title="View Profile"
                                onClick={() => navigate(`/employees/${emp._id}`)}
                                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                              >
                                <Eye size={18} />
                              </button>
                              <button
                                title="Edit"
                                onClick={() => navigate(`/employees/${emp._id}/edit`)}
                                className="p-2 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition-all"
                              >
                                <Edit2 size={18} />
                              </button>
                              {isAdmin && (
                                <button
                                  title="Delete"
                                  onClick={() => setToDelete(emp)}
                                  className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-all"
                                >
                                  <Trash2 size={18} />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))
                }
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="p-4 border-t border-slate-100 bg-slate-50/30 flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-2 text-sm font-medium text-slate-500">
              <span>Rows per page:</span>
              <select
                value={limit}
                onChange={(e) => { setLimit(Number(e.target.value)); setPage(1); }}
                className="bg-white border border-slate-200 rounded px-2 py-1 text-xs outline-none"
              >
                {[10, 25, 50].map((n) => <option key={n} value={n}>{n}</option>)}
              </select>
            </div>

            <div className="flex items-center gap-1">
              <button
                disabled={!meta?.hasPrev}
                onClick={() => setPage((p) => p - 1)}
                className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={18} />
              </button>

              {pageNumbers.map((n) => (
                <button
                  key={n}
                  onClick={() => setPage(n)}
                  className={`w-8 h-8 rounded-lg text-sm font-bold transition-colors ${
                    n === page
                      ? 'bg-blue-600 text-white shadow-md shadow-blue-500/20'
                      : 'hover:bg-slate-100 text-slate-600'
                  }`}
                >
                  {n}
                </button>
              ))}

              {totalPages > 5 && page < totalPages - 2 && (
                <>
                  <span className="px-1 text-slate-400">…</span>
                  <button
                    onClick={() => setPage(totalPages)}
                    className="w-8 h-8 rounded-lg text-sm font-bold hover:bg-slate-100 text-slate-600 transition-colors"
                  >
                    {totalPages}
                  </button>
                </>
              )}

              <button
                disabled={!meta?.hasNext}
                onClick={() => setPage((p) => p + 1)}
                className="p-1.5 hover:bg-slate-100 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Delete confirmation modal */}
      {toDelete && (
        <DeleteModal
          employee={toDelete}
          onConfirm={confirmDelete}
          onCancel={() => setToDelete(null)}
          isDeleting={isDeleting}
        />
      )}

      {/* Toast notification */}
      <Toast toast={toast} />
    </div>
  );
};

export default Employees;
