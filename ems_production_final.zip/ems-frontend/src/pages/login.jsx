// src/pages/Login.jsx
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, Loader2, ShieldCheck, AlertCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

// ── Inline field-error component ──────────────────────────────────────────────
const FieldError = ({ msg }) =>
  msg ? (
    <p className="flex items-center gap-1.5 text-xs font-semibold text-red-600 mt-1.5">
      <AlertCircle size={13} />
      {msg}
    </p>
  ) : null;

// ─────────────────────────────────────────────────────────────────────────────

const Login = () => {
  const { login } = useAuth();
  const location  = useLocation();

  const [form, setForm] = useState({ email: '', password: '' });
  const [fieldErrors, setFieldErrors] = useState({});   // { email: '…', password: '…' }
  const [serverError, setServerError] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading,    setIsLoading]    = useState(false);

  // ── Handlers ────────────────────────────────────────────────────────────

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    // Clear that field's error as the user starts correcting it
    if (fieldErrors[name]) setFieldErrors((p) => ({ ...p, [name]: '' }));
    if (serverError)       setServerError('');
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setFieldErrors({});
    setServerError('');

    try {
      await login(form.email, form.password);
      // AuthContext navigates to '/' (or back to location.state.from) on success
    } catch (err) {
      // Field-level validation errors from express-validator
      if (err.errors?.length) {
        const mapped = {};
        err.errors.forEach(({ field, message }) => { mapped[field] = message; });
        setFieldErrors(mapped);
      } else {
        // 401 "Invalid email or password" or other server message
        setServerError(err.message || 'Login failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  // ── Redirect message (e.g. came from a protected route) ─────────────────

  const redirectedFrom = location.state?.from?.pathname;

  return (
    <div className="min-h-screen bg-[#F8F9FF] flex flex-col items-center justify-center p-6">
      <div className="mb-8 flex flex-col items-center">
        <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20 mb-4">
          <ShieldCheck className="text-white" size={32} />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">HR Precision</h1>
        <p className="text-slate-500 mt-2 font-medium">Enterprise Employee Management</p>
      </div>

      <div className="bg-white w-full max-w-md p-8 rounded-3xl border border-slate-200 shadow-xl shadow-blue-500/5">
        <div className="mb-8 text-center">
          <h2 className="text-xl font-bold text-slate-900">Sign in to your account</h2>
          <p className="text-slate-500 text-[10px] mt-1 uppercase tracking-wider font-bold">
            Internal Admin Access Only
          </p>
        </div>

        {/* Redirect notice */}
        {redirectedFrom && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-2">
            <AlertCircle size={16} className="text-amber-600 shrink-0" />
            <p className="text-xs font-semibold text-amber-800">
              Sign in to continue to <span className="font-bold">{redirectedFrom}</span>
            </p>
          </div>
        )}

        {/* Global server error */}
        {serverError && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2">
            <AlertCircle size={16} className="text-red-600 shrink-0" />
            <p className="text-sm font-semibold text-red-700">{serverError}</p>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-5" noValidate>

          {/* Email */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Email address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="email"
                type="email"
                autoComplete="email"
                placeholder="admin@hrprecision.com"
                value={form.email}
                onChange={handleChange}
                className={`w-full pl-12 pr-4 py-3 bg-slate-50 border rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all outline-none text-slate-900 font-medium ${
                  fieldErrors.email ? 'border-red-400 bg-red-50' : 'border-slate-200'
                }`}
              />
            </div>
            <FieldError msg={fieldErrors.email} />
          </div>

          {/* Password */}
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <label className="text-sm font-semibold text-slate-700">Password</label>
              <button type="button" className="text-xs font-bold text-blue-600 hover:underline">
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="current-password"
                placeholder="••••••••"
                value={form.password}
                onChange={handleChange}
                className={`w-full pl-12 pr-12 py-3 bg-slate-50 border rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all outline-none text-slate-900 font-medium tracking-widest ${
                  fieldErrors.password ? 'border-red-400 bg-red-50' : 'border-slate-200'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition-colors"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <FieldError msg={fieldErrors.password} />
          </div>

          {/* Remember me */}
          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="remember"
              className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500 cursor-pointer"
            />
            <label htmlFor="remember" className="text-sm font-medium text-slate-600 cursor-pointer">
              Remember this device for 30 days
            </label>
          </div>

          {/* Submit */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'Sign In'}
          </button>
        </form>
      </div>

      <div className="mt-8 text-center">
        <p className="text-slate-500 text-sm">
          Need an account?{' '}
          <Link to="/register" className="text-blue-600 font-bold hover:underline">
            Register here
          </Link>
        </p>
        <div className="flex items-center gap-6 mt-6 justify-center">
          <button className="text-xs text-slate-400 hover:text-slate-600 transition-colors">Privacy Policy</button>
          <button className="text-xs text-slate-400 hover:text-slate-600 transition-colors">Terms of Service</button>
          <button className="text-xs text-slate-400 hover:text-slate-600 transition-colors">Support</button>
        </div>
      </div>
    </div>
  );
};

export default Login;
