// src/pages/register.jsx
import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, Lock, Eye, EyeOff, User, Loader2, ShieldCheck, AlertCircle, ChevronRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const FieldError = ({ msg }) =>
  msg ? (
    <p className="flex items-center gap-1.5 text-xs font-semibold text-red-600 mt-1.5">
      <AlertCircle size={13} />
      {msg}
    </p>
  ) : null;

const Register = () => {
  const { register } = useAuth();

  const [form, setForm] = useState({
    name: '', email: '', password: '', confirmPassword: '', role: 'hr',
  });
  const [fieldErrors,   setFieldErrors]   = useState({});
  const [serverError,   setServerError]   = useState('');
  const [showPassword,  setShowPassword]  = useState(false);
  const [showConfirm,   setShowConfirm]   = useState(false);
  const [isLoading,     setIsLoading]     = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((p) => ({ ...p, [name]: value }));
    if (fieldErrors[name]) setFieldErrors((p) => ({ ...p, [name]: '' }));
    if (serverError)        setServerError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setFieldErrors({});
    setServerError('');

    // Client-side confirm-password check before hitting the API
    if (form.password !== form.confirmPassword) {
      setFieldErrors({ confirmPassword: 'Passwords do not match.' });
      return;
    }

    setIsLoading(true);
    try {
      const { name, email, password, role } = form;
      await register({ name, email, password, role });
      // AuthContext navigates to '/' on success
    } catch (err) {
      if (err.errors?.length) {
        const mapped = {};
        err.errors.forEach(({ field, message }) => { mapped[field] = message; });
        setFieldErrors(mapped);
      } else {
        setServerError(err.message || 'Registration failed. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const inputClass = (field) =>
    `w-full pl-11 pr-4 py-3 bg-slate-50 border rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all outline-none text-slate-900 font-medium text-sm ${
      fieldErrors[field] ? 'border-red-400 bg-red-50' : 'border-slate-200'
    }`;

  return (
    <div className="min-h-screen bg-[#F8F9FF] flex flex-col items-center justify-center p-6">
      {/* Logo */}
      <div className="mb-8 flex flex-col items-center">
        <div className="w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-500/20 mb-4">
          <ShieldCheck className="text-white" size={32} />
        </div>
        <h1 className="text-3xl font-bold text-slate-900 tracking-tight">HR Precision</h1>
        <p className="text-slate-500 mt-2 font-medium">Enterprise Employee Management</p>
      </div>

      <div className="bg-white w-full max-w-md p-8 rounded-3xl border border-slate-200 shadow-xl shadow-blue-500/5">
        <div className="mb-8 text-center">
          <h2 className="text-xl font-bold text-slate-900">Create your account</h2>
          <p className="text-slate-500 text-[10px] mt-1 uppercase tracking-wider font-bold">
            Admin / HR Access Only
          </p>
        </div>

        {serverError && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2">
            <AlertCircle size={16} className="text-red-600 shrink-0" />
            <p className="text-sm font-semibold text-red-700">{serverError}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5" noValidate>
          {/* Full Name */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Full name</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="name"
                type="text"
                placeholder="Alex Thompson"
                value={form.name}
                onChange={handleChange}
                className={inputClass('name')}
              />
            </div>
            <FieldError msg={fieldErrors.name} />
          </div>

          {/* Email */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Email address</label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="email"
                type="email"
                autoComplete="email"
                placeholder="admin@hrprecision.com"
                value={form.email}
                onChange={handleChange}
                className={inputClass('email')}
              />
            </div>
            <FieldError msg={fieldErrors.email} />
          </div>

          {/* Role */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Role</label>
            <div className="relative">
              <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <select
                name="role"
                value={form.role}
                onChange={handleChange}
                className="w-full pl-11 pr-10 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-4 focus:ring-blue-500/10 focus:border-blue-500 transition-all outline-none text-slate-900 font-medium text-sm appearance-none"
              >
                <option value="hr">HR</option>
                <option value="manager">Manager</option>
                <option value="admin">Admin</option>
              </select>
              <ChevronRight className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 rotate-90 pointer-events-none" size={16} />
            </div>
          </div>

          {/* Password */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Min 8 chars, 1 uppercase, 1 number"
                value={form.password}
                onChange={handleChange}
                className={`${inputClass('password')} pr-12 tracking-widest`}
              />
              <button
                type="button"
                onClick={() => setShowPassword((s) => !s)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <FieldError msg={fieldErrors.password} />
          </div>

          {/* Confirm Password */}
          <div className="space-y-1">
            <label className="text-sm font-semibold text-slate-700">Confirm password</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                required
                name="confirmPassword"
                type={showConfirm ? 'text' : 'password'}
                placeholder="Repeat your password"
                value={form.confirmPassword}
                onChange={handleChange}
                className={`${inputClass('confirmPassword')} pr-12 tracking-widest`}
              />
              <button
                type="button"
                onClick={() => setShowConfirm((s) => !s)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                {showConfirm ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <FieldError msg={fieldErrors.confirmPassword} />
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full py-4 bg-blue-600 text-white font-bold rounded-xl hover:bg-blue-700 active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-500/20 disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {isLoading ? <Loader2 className="animate-spin" size={20} /> : 'Create Account'}
          </button>
        </form>
      </div>

      <p className="mt-6 text-slate-500 text-sm">
        Already have an account?{' '}
        <Link to="/login" className="text-blue-600 font-bold hover:underline">Sign in</Link>
      </p>
    </div>
  );
};

export default Register;
