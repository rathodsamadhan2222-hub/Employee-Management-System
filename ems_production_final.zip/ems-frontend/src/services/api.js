// src/services/api.js
// ─── Centralized Axios instance ───────────────────────────────────────────────
// Single source of truth for all HTTP calls.
// Handles: base URL, JWT injection, token refresh, unified error shape.

import axios from 'axios';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// ── Base instance ─────────────────────────────────────────────────────────────

const api = axios.create({
  baseURL:         BASE_URL,
  withCredentials: true,          // sends httpOnly refresh-token cookie
  headers:         { 'Content-Type': 'application/json' },
  timeout:         15000,         // 15 s timeout
});

// ── Request interceptor — inject Bearer token ─────────────────────────────────

api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) config.headers.Authorization = `Bearer ${token}`;
    return config;
  },
  (error) => Promise.reject(error),
);

// ── Response interceptor — silent token refresh on 401 ────────────────────────

let isRefreshing = false;
let failedQueue  = [];

const processQueue = (error, token = null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token)));
  failedQueue = [];
};

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;

    if (error.response?.status === 401 && !original._retry) {
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        })
          .then((token) => {
            original.headers.Authorization = `Bearer ${token}`;
            return api(original);
          });
      }

      original._retry = true;
      isRefreshing    = true;

      try {
        const { data } = await api.post('/auth/refresh');
        const newToken = data.data.accessToken;
        localStorage.setItem('accessToken', newToken);
        api.defaults.headers.common.Authorization = `Bearer ${newToken}`;
        processQueue(null, newToken);
        original.headers.Authorization = `Bearer ${newToken}`;
        return api(original);
      } catch (refreshErr) {
        processQueue(refreshErr, null);
        localStorage.removeItem('accessToken');
        localStorage.removeItem('user');
        window.dispatchEvent(new Event('auth:logout'));   // AuthContext listens to this
        return Promise.reject(refreshErr);
      } finally {
        isRefreshing = false;
      }
    }

    // ── Normalize error shape ─────────────────────────────────────────────────
    // Every catch block in the app can reliably read err.message
    // and err.errors for field-level validation errors.
    const normalized = {
      message: error.response?.data?.message
               || error.message
               || 'Something went wrong. Please try again.',
      errors:  error.response?.data?.errors || [],
      status:  error.response?.status || 0,
    };
    return Promise.reject(normalized);
  },
);

export default api;
