// src/services/authService.js
// ─── Auth API calls ───────────────────────────────────────────────────────────

import api from './api';

const authService = {

  // POST /api/auth/register
  // body: { name, email, password, role? }
  // Returns: { user, accessToken }
  register: (data) =>
    api.post('/auth/register', data),

  // POST /api/auth/login
  // body: { email, password }
  // Returns: { user, accessToken }
  login: (data) =>
    api.post('/auth/login', data),

  // POST /api/auth/logout  (requires Bearer token)
  logout: () =>
    api.post('/auth/logout'),

  // GET /api/auth/profile  (requires Bearer token)
  // Returns: { user }
  getProfile: () =>
    api.get('/auth/profile'),

  // POST /api/auth/refresh  (refresh token via httpOnly cookie)
  // Returns: { accessToken }
  refresh: () =>
    api.post('/auth/refresh'),
};

export default authService;
