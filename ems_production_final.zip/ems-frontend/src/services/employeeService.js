// src/services/employeeService.js
import api from './api';

const clean = (params) =>
  Object.fromEntries(
    Object.entries(params).filter(([, v]) => v !== undefined && v !== '' && v !== null),
  );

const employeeService = {
  getAll:                (params = {}) => api.get('/employees',              { params: clean(params) }),
  getStats:              ()            => api.get('/employees/stats'),
  getRecent:             (limit = 4)   => api.get('/employees/recent',       { params: { limit } }),
  search:                (q, limit=8)  => api.get('/employees/search',       { params: clean({ q, limit }) }),
  getDepartmentBreakdown:()            => api.get('/employees/departments'),
  getById:               (id)          => api.get(`/employees/${id}`),
  create:                (data)        => api.post('/employees', data),
  update:                (id, data)    => api.put(`/employees/${id}`, data),
  remove:                (id)          => api.delete(`/employees/${id}`),
};

export const dashboardService = {
  getStats: () => api.get('/dashboard/stats'),
};

export default employeeService;
