const authService           = require('../services/authService');
const { sendSuccess,
        sendError }         = require('../utils/response');
const { refreshCookieOptions } = require('../utils/jwt');

// ─── POST /api/auth/register ──────────────────────────────────────────────────

const register = async (req, res, next) => {
  try {
    const { name, email, password, role } = req.body;
    const result = await authService.register({ name, email, password, role });

    // Set refresh token as httpOnly cookie
    res.cookie('refreshToken', result.refreshToken, refreshCookieOptions);

    return sendSuccess(res, 201, 'Account created successfully.', {
      user:        result.user,
      accessToken: result.accessToken,
    });
  } catch (err) {
    next(err);
  }
};

// ─── POST /api/auth/login ─────────────────────────────────────────────────────

const login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const result = await authService.login({ email, password });

    res.cookie('refreshToken', result.refreshToken, refreshCookieOptions);

    return sendSuccess(res, 200, 'Logged in successfully.', {
      user:        result.user,
      accessToken: result.accessToken,
    });
  } catch (err) {
    next(err);
  }
};

// ─── POST /api/auth/refresh ───────────────────────────────────────────────────

const refresh = async (req, res, next) => {
  try {
    // Accept token from httpOnly cookie OR request body (mobile clients)
    const token = req.cookies?.refreshToken || req.body?.refreshToken;
    if (!token) {
      return sendError(res, 401, 'Refresh token is required.');
    }

    const result = await authService.refreshAccessToken(token);

    res.cookie('refreshToken', result.refreshToken, refreshCookieOptions);

    return sendSuccess(res, 200, 'Token refreshed successfully.', {
      accessToken: result.accessToken,
    });
  } catch (err) {
    next(err);
  }
};

// ─── POST /api/auth/logout ────────────────────────────────────────────────────

const logout = async (req, res, next) => {
  try {
    await authService.logout(req.user._id);

    // Clear the httpOnly cookie
    res.clearCookie('refreshToken', {
      httpOnly: true,
      secure:   process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      path:     '/api/auth/refresh',
    });

    return sendSuccess(res, 200, 'Logged out successfully.');
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/auth/profile ────────────────────────────────────────────────────

const getProfile = async (req, res, next) => {
  try {
    const user = await authService.getProfile(req.user._id);
    return sendSuccess(res, 200, 'Profile fetched successfully.', { user });
  } catch (err) {
    next(err);
  }
};

module.exports = { register, login, refresh, logout, getProfile };
