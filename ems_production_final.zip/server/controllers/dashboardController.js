// server/controllers/dashboardController.js
const Employee        = require('../models/Employee');
const { sendSuccess } = require('../utils/response');

// ─── GET /api/dashboard/stats ─────────────────────────────────────────────────
//
// Single round-trip aggregation returning everything the Dashboard needs:
//   totalEmployees    – all employees in the collection
//   activeEmployees   – status === 'Active'
//   totalDepartments  – distinct department count
//   newThisMonth      – created since the 1st of the current month
//   departmentBreakdown – [{ department, total, active }] sorted by total desc
//   recentEmployees   – last 5 added (id, name, email, dept, designation, status, joiningDate)
//   monthlyGrowth     – last 6 months new-hire counts for the sparkline chart

const getStats = async (req, res, next) => {
  try {
    const now        = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    // ── 1. Core counts via $facet (single aggregation) ────────────────────

    const [counts] = await Employee.aggregate([
      {
        $facet: {
          total:       [{ $count: 'n' }],
          active:      [{ $match: { status: 'Active' } },       { $count: 'n' }],
          departments: [{ $group: { _id: '$department' } },      { $count: 'n' }],
          newMonth:    [{ $match: { createdAt: { $gte: monthStart } } }, { $count: 'n' }],
        },
      },
      {
        $project: {
          totalEmployees:   { $ifNull: [{ $arrayElemAt: ['$total.n',       0] }, 0] },
          activeEmployees:  { $ifNull: [{ $arrayElemAt: ['$active.n',      0] }, 0] },
          totalDepartments: { $ifNull: [{ $arrayElemAt: ['$departments.n', 0] }, 0] },
          newThisMonth:     { $ifNull: [{ $arrayElemAt: ['$newMonth.n',    0] }, 0] },
        },
      },
    ]);

    // ── 2. Department breakdown ────────────────────────────────────────────

    const departmentBreakdown = await Employee.aggregate([
      {
        $group: {
          _id:    '$department',
          total:  { $sum: 1 },
          active: { $sum: { $cond: [{ $eq: ['$status', 'Active'] }, 1, 0] } },
        },
      },
      { $sort: { total: -1 } },
      { $project: { _id: 0, department: '$_id', total: 1, active: 1 } },
    ]);

    // ── 3. Recent employees (last 5) ──────────────────────────────────────

    const recentEmployees = await Employee
      .find()
      .sort({ createdAt: -1 })
      .limit(5)
      .select('employeeId fullName email department designation status joiningDate createdAt')
      .lean();

    // ── 4. Monthly growth — last 6 months ─────────────────────────────────
    // Returns [{ month: 'Jan', year: 2024, count: 12 }, …] for chart rendering.

    const sixMonthsAgo = new Date();
    sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
    sixMonthsAgo.setDate(1);
    sixMonthsAgo.setHours(0, 0, 0, 0);

    const monthlyGrowthRaw = await Employee.aggregate([
      { $match: { createdAt: { $gte: sixMonthsAgo } } },
      {
        $group: {
          _id:   { year: { $year: '$createdAt' }, month: { $month: '$createdAt' } },
          count: { $sum: 1 },
        },
      },
      { $sort: { '_id.year': 1, '_id.month': 1 } },
    ]);

    // Fill in zero-count months so the chart always has 6 data points
    const MONTH_NAMES = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    const monthlyGrowth = [];
    for (let i = 5; i >= 0; i--) {
      const d     = new Date();
      d.setMonth(d.getMonth() - i);
      const yr    = d.getFullYear();
      const mo    = d.getMonth() + 1;   // 1-based
      const found = monthlyGrowthRaw.find((r) => r._id.year === yr && r._id.month === mo);
      monthlyGrowth.push({
        month: MONTH_NAMES[mo - 1],
        year:  yr,
        count: found?.count || 0,
      });
    }

    // ── 5. Status distribution (pie chart data) ───────────────────────────

    const statusDistribution = await Employee.aggregate([
      { $group: { _id: '$status', count: { $sum: 1 } } },
      { $project: { _id: 0, status: '$_id', count: 1 } },
      { $sort: { count: -1 } },
    ]);

    return sendSuccess(res, 200, 'Dashboard stats fetched successfully.', {
      // Stat cards
      totalEmployees:    counts.totalEmployees,
      activeEmployees:   counts.activeEmployees,
      totalDepartments:  counts.totalDepartments,
      newThisMonth:      counts.newThisMonth,
      // Charts + tables
      departmentBreakdown,
      recentEmployees,
      monthlyGrowth,
      statusDistribution,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = { getStats };
