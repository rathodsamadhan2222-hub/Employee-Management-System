const employeeService = require('../services/employeeService');
const { sendSuccess, sendError } = require('../utils/response');

// ─── GET /api/employees ───────────────────────────────────────────────────────
//
// Supported query params (all optional, all combinable):
//
//   Pagination
//     ?page=1               default 1
//     ?limit=10             default 10, max 100
//
//   Search (full-text on name / email / designation)
//     ?search=john
//
//   Exact-match filters
//     ?department=Engineering
//     ?status=Active
//     ?employmentType=Full-time+Regular
//
//   Sorting
//     ?sort=joiningDate     field to sort by (default: createdAt)
//     ?order=asc            asc | desc (default: desc)
//
//   Combined examples
//     ?search=john&department=Engineering&sort=joiningDate&order=asc&page=2&limit=25
//     ?status=Active&sort=fullName&order=asc
//     ?department=HR&status=Active&page=1&limit=5

const getAll = async (req, res, next) => {
  try {
    const {
      page,
      limit,
      search,
      department,
      status,
      employmentType,
      sort,
      order,
    } = req.query;

    const result = await employeeService.getAll({
      page,
      limit,
      search,
      department,
      status,
      employmentType,
      sort,
      order,
    });

    return sendSuccess(
      res,
      200,
      'Employees fetched successfully.',
      result.employees,
      result.meta,
    );
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/employees/stats ─────────────────────────────────────────────────
//
// Returns aggregated counts for the Dashboard StatCards:
//   { total, active, departments, newThisMonth }

const getStats = async (req, res, next) => {
  try {
    const stats = await employeeService.getDashboardStats();
    return sendSuccess(res, 200, 'Dashboard stats fetched successfully.', stats);
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/employees/recent ────────────────────────────────────────────────
//
// Returns the N most recently added employees.
//   ?limit=4   (default 4, max capped in service)

const getRecent = async (req, res, next) => {
  try {
    const limit     = Math.min(20, parseInt(req.query.limit, 10) || 4);
    const employees = await employeeService.getRecent(limit);
    return sendSuccess(res, 200, 'Recent employees fetched successfully.', employees);
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/employees/search ────────────────────────────────────────────────
//
// Lightweight global search for the Navbar search bar.
// Returns a trimmed projection — no pagination.
//   ?q=john            search term (required, min 2 chars)
//   ?limit=8           max results (default 8)

const search = async (req, res, next) => {
  try {
    const { q, limit } = req.query;

    if (!q || q.trim().length < 2) {
      return sendError(res, 400, "Query param 'q' is required and must be at least 2 characters.");
    }

    const results = await employeeService.globalSearch(q.trim(), limit);
    return sendSuccess(res, 200, 'Search results fetched.', results);
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/employees/departments ──────────────────────────────────────────
//
// Returns per-department employee counts.
//   [{ department: 'Engineering', total: 42, active: 38 }, …]

const getDepartmentBreakdown = async (req, res, next) => {
  try {
    const breakdown = await employeeService.getDepartmentBreakdown();
    return sendSuccess(res, 200, 'Department breakdown fetched.', breakdown);
  } catch (err) {
    next(err);
  }
};

// ─── GET /api/employees/:id ───────────────────────────────────────────────────
//
// Returns a single employee with populated createdBy and updatedBy refs.

const getById = async (req, res, next) => {
  try {
    const employee = await employeeService.getById(req.params.id);
    return sendSuccess(res, 200, 'Employee fetched successfully.', employee);
  } catch (err) {
    next(err);
  }
};

// ─── POST /api/employees ──────────────────────────────────────────────────────
//
// Creates a new employee. Requires admin or hr role.
// employeeId (EMP-XXXXX) is auto-generated — do not send it in the body.
//
// Required body fields:
//   fullName, email, department, designation, joiningDate
//
// Optional body fields:
//   mobileNumber, dateOfBirth, employmentType, status

const create = async (req, res, next) => {
  try {
    const employee = await employeeService.create(req.body, req.user._id);
    return sendSuccess(res, 201, 'Employee added successfully.', employee);
  } catch (err) {
    next(err);
  }
};

// ─── PUT /api/employees/:id ───────────────────────────────────────────────────
//
// Updates an existing employee. All body fields are optional (partial update).
// Fields that cannot be changed via this endpoint:
//   employeeId, createdBy, createdAt  (stripped in service layer)

const update = async (req, res, next) => {
  try {
    const employee = await employeeService.update(req.params.id, req.body, req.user._id);
    return sendSuccess(res, 200, 'Employee updated successfully.', employee);
  } catch (err) {
    next(err);
  }
};

// ─── DELETE /api/employees/:id ────────────────────────────────────────────────
//
// Permanently deletes an employee. Restricted to admin role only.
// Returns the deleted employee's basic info for confirmation in the UI.

const remove = async (req, res, next) => {
  try {
    const deleted = await employeeService.remove(req.params.id);
    return sendSuccess(res, 200, 'Employee deleted successfully.', {
      id:         deleted._id,
      employeeId: deleted.employeeId,
      fullName:   deleted.fullName,
    });
  } catch (err) {
    next(err);
  }
};

module.exports = {
  getAll,
  getStats,
  getRecent,
  search,
  getDepartmentBreakdown,
  getById,
  create,
  update,
  remove,
};
