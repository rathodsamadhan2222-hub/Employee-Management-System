const { verifyAccessToken } = require('../utils/jwt');
const { sendError }         = require('../utils/response');
const User                  = require('../models/User');

// ─── protect ─────────────────────────────────────────────────────────────────

/**
 * Verifies the Bearer token in the Authorization header.
 * Attaches the full user document (minus password) to req.user.
 */
const protect = async (req, res, next) => {
  try {
    // 1. Extract token
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return sendError(res, 401, 'Access denied. No token provided.');
    }

    const token = authHeader.split(' ')[1];

    // 2. Verify signature + expiry
    let decoded;
    try {
      decoded = verifyAccessToken(token);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return sendError(res, 401, 'Access token has expired. Please refresh.');
      }
      return sendError(res, 401, 'Invalid token.');
    }

    // 3. Check user still exists and is active
    const user = await User.findById(decoded.id).select('+passwordChangedAt');
    if (!user) {
      return sendError(res, 401, 'User associated with this token no longer exists.');
    }

    if (!user.isActive) {
      return sendError(res, 403, 'Your account has been deactivated. Contact admin.');
    }

    // 4. Check if password was changed after token was issued
    if (user.passwordChangedAfter(decoded.iat)) {
      return sendError(res, 401, 'Password was recently changed. Please log in again.');
    }

    // 5. Attach user to request
    req.user = user;
    next();
  } catch (error) {
    next(error);
  }
};

// ─── authorize ────────────────────────────────────────────────────────────────

/**
 * Role-based access control.
 * Usage: authorize('admin', 'hr')
 * @param  {...string} roles  — allowed roles
 */
const authorize = (...roles) =>
  (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return sendError(
        res,
        403,
        `Role '${req.user.role}' is not authorized to access this resource.`
      );
    }
    next();
  };

module.exports = { protect, authorize };
