const { sendError } = require('../utils/response');

/**
 * Global error handler. Must be the LAST middleware registered in server.js.
 * Express identifies it by its 4-argument signature (err, req, res, next).
 */
const errorHandler = (err, req, res, next) => {  // eslint-disable-line no-unused-vars
  let statusCode = err.statusCode || 500;
  let message    = err.message    || 'Internal Server Error';

  // ── Mongoose CastError (invalid ObjectId) ──────────────────────────────────
  if (err.name === 'CastError') {
    statusCode = 400;
    message    = `Invalid value for field: ${err.path}`;
  }

  // ── Mongoose Duplicate Key (unique constraint) ─────────────────────────────
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyPattern || {})[0];
    message = `A record with this ${field} already exists.`;
  }

  // ── Mongoose ValidationError ───────────────────────────────────────────────
  if (err.name === 'ValidationError') {
    statusCode = 422;
    const errors = Object.values(err.errors).map((e) => ({
      field:   e.path,
      message: e.message,
    }));
    return sendError(res, statusCode, 'Validation failed', errors);
  }

  // ── JWT errors (should be caught in middleware, but safety net) ───────────
  if (err.name === 'JsonWebTokenError')  { statusCode = 401; message = 'Invalid token.'; }
  if (err.name === 'TokenExpiredError')  { statusCode = 401; message = 'Token has expired.'; }

  // ── Log unexpected server errors ───────────────────────────────────────────
  if (statusCode === 500) {
    console.error('🔴 Unhandled error:', err);
  }

  return sendError(res, statusCode, message);
};

/**
 * 404 handler — mount BEFORE errorHandler, AFTER all routes.
 */
const notFound = (req, res) => {
  sendError(res, 404, `Route not found: ${req.method} ${req.originalUrl}`);
};

module.exports = { errorHandler, notFound };
