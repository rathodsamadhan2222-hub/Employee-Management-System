const mongoose = require('mongoose');

// ─── Constants ────────────────────────────────────────────────────────────────

const DEPARTMENTS = [
  'Engineering',
  'Product Design',
  'Marketing',
  'Sales',
  'HR',
  'Finance',
  'Operations',
  'Legal',
];

const EMPLOYMENT_TYPES = [
  'Full-time Regular',
  'Full-time Contract',
  'Part-time',
  'Internship',
];

const STATUS = ['Active', 'Inactive', 'On Leave', 'Terminated'];

// ─── Counter helper for auto-generated Employee ID ────────────────────────────

const counterSchema = new mongoose.Schema({
  _id:   { type: String, required: true },
  seq:   { type: Number, default: 0 },
});
const Counter = mongoose.model('Counter', counterSchema);

// ─── Schema ────────────────────────────────────────────────────────────────────

const employeeSchema = new mongoose.Schema(
  {
    // Auto-generated readable ID: EMP-00001
    employeeId: {
      type:   String,
    },

    // ── Personal Information ────────────────────────────────────────────────

    fullName: {
      type:      String,
      required:  [true, 'Full name is required'],
      trim:      true,
      minlength: [2,  'Full name must be at least 2 characters'],
      maxlength: [80, 'Full name must not exceed 80 characters'],
    },

    email: {
      type:      String,
      required:  [true, 'Email is required'],
      lowercase: true,
      trim:      true,
      match: [
        /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/,
        'Please provide a valid email address',
      ],
    },

    mobileNumber: {
      type:  String,
      trim:  true,
      match: [
        /^\+?[1-9]\d{1,14}$/,
        'Please provide a valid mobile number (E.164 format)',
      ],
    },

    dateOfBirth: {
      type: Date,
    },

    // ── Job Details ─────────────────────────────────────────────────────────

    department: {
      type:     String,
      required: [true, 'Department is required'],
      enum: {
        values:  DEPARTMENTS,
        message: '{VALUE} is not a valid department',
      },
    },

    designation: {
      type:      String,
      required:  [true, 'Designation is required'],
      trim:      true,
      maxlength: [100, 'Designation must not exceed 100 characters'],
    },

    employmentType: {
      type:    String,
      enum: {
        values:  EMPLOYMENT_TYPES,
        message: '{VALUE} is not a valid employment type',
      },
      default: 'Full-time Regular',
    },

    joiningDate: {
      type:     Date,
      required: [true, 'Joining date is required'],
    },

    // ── Status & Metadata ────────────────────────────────────────────────────

    status: {
      type:    String,
      enum: {
        values:  STATUS,
        message: '{VALUE} is not a valid status',
      },
      default: 'Active',
    },

    // Relationship: which admin/hr user added this employee
    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref:  'User',
      required: true,
    },

    updatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref:  'User',
    },
  },
  {
    timestamps: true,   // auto createdAt + updatedAt
    versionKey: false,
  }
);

// ─── Indexes ──────────────────────────────────────────────────────────────────

// Primary lookup
employeeSchema.index({ employeeId: 1 }, { unique: true });
employeeSchema.index({ email:      1 }, { unique: true });

// Filtering & sorting
employeeSchema.index({ department: 1 });
employeeSchema.index({ status:     1 });
employeeSchema.index({ joiningDate: -1 });

// Text search across name + email + designation
employeeSchema.index(
  { fullName: 'text', email: 'text', designation: 'text' },
  { weights: { fullName: 3, designation: 2, email: 1 }, name: 'employee_text_search' }
);

// Compound: common dashboard filter
employeeSchema.index({ department: 1, status: 1 });

// ─── Pre-save hook — generate employeeId ─────────────────────────────────────

employeeSchema.pre('save', async function (next) {
  if (!this.isNew) return next();

  try {
    const counter = await Counter.findByIdAndUpdate(
      { _id: 'employeeId' },
      { $inc: { seq: 1 } },
      { new: true, upsert: true }
    );
    this.employeeId = `EMP-${String(counter.seq).padStart(5, '0')}`;
    next();
  } catch (err) {
    next(err);
  }
});

// ─── Virtual ─────────────────────────────────────────────────────────────────

// Returns years of service (useful for anniversary milestones)
employeeSchema.virtual('yearsOfService').get(function () {
  if (!this.joiningDate) return null;
  const ms   = Date.now() - new Date(this.joiningDate).getTime();
  return Math.floor(ms / (1000 * 60 * 60 * 24 * 365.25));
});

// ─── Serialization ────────────────────────────────────────────────────────────

employeeSchema.set('toJSON',   { virtuals: true });
employeeSchema.set('toObject', { virtuals: true });

// ─── Statics ─────────────────────────────────────────────────────────────────

/**
 * Aggregate stats for the Dashboard.
 * Returns total, active, departments count, new this month.
 */
employeeSchema.statics.getDashboardStats = async function () {
  const now         = new Date();
  const monthStart  = new Date(now.getFullYear(), now.getMonth(), 1);

  const [stats] = await this.aggregate([
    {
      $facet: {
        total:          [{ $count: 'count' }],
        active:         [{ $match: { status: 'Active' } }, { $count: 'count' }],
        departments:    [{ $group: { _id: '$department' } }, { $count: 'count' }],
        newThisMonth:   [{ $match: { createdAt: { $gte: monthStart } } }, { $count: 'count' }],
      },
    },
    {
      $project: {
        total:        { $arrayElemAt: ['$total.count',        0] },
        active:       { $arrayElemAt: ['$active.count',       0] },
        departments:  { $arrayElemAt: ['$departments.count',  0] },
        newThisMonth: { $arrayElemAt: ['$newThisMonth.count', 0] },
      },
    },
  ]);

  return {
    total:        stats.total        || 0,
    active:       stats.active       || 0,
    departments:  stats.departments  || 0,
    newThisMonth: stats.newThisMonth || 0,
  };
};

// ─── Model ────────────────────────────────────────────────────────────────────

const Employee = mongoose.model('Employee', employeeSchema);

module.exports = Employee;
module.exports.DEPARTMENTS     = DEPARTMENTS;
module.exports.EMPLOYMENT_TYPES = EMPLOYMENT_TYPES;
module.exports.STATUS          = STATUS;
