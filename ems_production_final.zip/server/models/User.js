const mongoose = require('mongoose');
const bcrypt   = require('bcryptjs');

// ─── Schema ────────────────────────────────────────────────────────────────────

const userSchema = new mongoose.Schema(
  {
    name: {
      type:      String,
      required:  [true, 'Name is required'],
      trim:      true,
      minlength: [2,  'Name must be at least 2 characters'],
      maxlength: [60, 'Name must not exceed 60 characters'],
    },

    email: {
      type:      String,
      required:  [true, 'Email is required'],
      lowercase: true,
      trim:      true,
      match: [
        /^[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}$/,
        'Please provide a valid email address',
      ],
    },

    password: {
      type:      String,
      required:  [true, 'Password is required'],
      minlength: [8, 'Password must be at least 8 characters'],
      select:    false,  // never returned in queries by default
    },

    role: {
      type:    String,
      enum:    {
        values:  ['admin', 'hr', 'manager'],
        message: '{VALUE} is not a valid role',
      },
      default: 'hr',
    },

    isActive: {
      type:    Boolean,
      default: true,
    },

    lastLogin: {
      type: Date,
    },

    // Refresh token stored hashed; supports single active session per user.
    // Remove this field and the related logic to allow multiple sessions.
    refreshToken: {
      type:   String,
      select: false,
    },

    passwordChangedAt: {
      type:   Date,
      select: false,
    },
  },
  {
    timestamps: true,        // adds createdAt + updatedAt automatically
    versionKey: false,
  }
);

// ─── Indexes ──────────────────────────────────────────────────────────────────

userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ role:  1 });
userSchema.index({ isActive: 1 });

// ─── Pre-save hook — hash password ────────────────────────────────────────────

userSchema.pre('save', async function (next) {
  // Only re-hash if password was actually modified
  if (!this.isModified('password')) return next();

  const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 12;
  this.password = await bcrypt.hash(this.password, saltRounds);

  // Track when password was changed (used to invalidate old JWTs)
  if (!this.isNew) {
    this.passwordChangedAt = Date.now() - 1000; // 1s buffer for token iat
  }

  next();
});

// ─── Instance methods ─────────────────────────────────────────────────────────

/**
 * Compare a plain-text candidate against the stored bcrypt hash.
 * @param {string} candidatePassword
 * @returns {Promise<boolean>}
 */
userSchema.methods.comparePassword = async function (candidatePassword) {
  return bcrypt.compare(candidatePassword, this.password);
};

/**
 * Returns true if the JWT was issued BEFORE the user changed their password.
 * @param {number} jwtIssuedAt  — seconds since epoch (jwt payload.iat)
 * @returns {boolean}
 */
userSchema.methods.passwordChangedAfter = function (jwtIssuedAt) {
  if (this.passwordChangedAt) {
    const changedTimestamp = parseInt(this.passwordChangedAt.getTime() / 1000, 10);
    return jwtIssuedAt < changedTimestamp;
  }
  return false;
};

/**
 * Serialize user to a safe public object (strips sensitive fields).
 * @returns {object}
 */
userSchema.methods.toPublicJSON = function () {
  return {
    id:        this._id,
    name:      this.name,
    email:     this.email,
    role:      this.role,
    isActive:  this.isActive,
    lastLogin: this.lastLogin,
    createdAt: this.createdAt,
  };
};

// ─── Model ────────────────────────────────────────────────────────────────────

const User = mongoose.model('User', userSchema);

module.exports = User;
