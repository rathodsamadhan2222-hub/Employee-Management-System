const express     = require('express');
const router      = express.Router();
const authCtrl    = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const {
  registerRules,
  loginRules,
  validate,
}                 = require('../validations/authValidation');

// POST /api/auth/register
router.post('/register', registerRules, validate, authCtrl.register);

// POST /api/auth/login
router.post('/login', loginRules, validate, authCtrl.login);

// POST /api/auth/refresh  — public (refresh token in cookie)
router.post('/refresh', authCtrl.refresh);

// Protected routes below
router.use(protect);

// POST /api/auth/logout
router.post('/logout', authCtrl.logout);

// GET /api/auth/profile
router.get('/profile', authCtrl.getProfile);

module.exports = router;
