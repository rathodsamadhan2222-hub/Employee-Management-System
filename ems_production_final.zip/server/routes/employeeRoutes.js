/**
 * Employee Routes
 * Base path: /api/employees  (mounted in server.js)
 *
 * ┌─────────────────────────────────────────────────────────────────────────┐
 * │ METHOD  ROUTE                        ROLE          DESCRIPTION          │
 * ├─────────────────────────────────────────────────────────────────────────┤
 * │ GET     /                            all           Paginated list        │
 * │ GET     /stats                       all           Dashboard counts      │
 * │ GET     /recent                      all           Latest N employees    │
 * │ GET     /search?q=                   all           Navbar global search  │
 * │ GET     /departments                 all           Per-dept breakdown    │
 * │ GET     /:id                         all           Single employee       │
 * │ POST    /                            admin, hr     Create employee       │
 * │ PUT     /:id                         admin, hr     Update employee       │
 * │ DELETE  /:id                         admin         Delete employee       │
 * └─────────────────────────────────────────────────────────────────────────┘
 *
 * Query param reference for GET /api/employees
 * ─────────────────────────────────────────────
 *  Pagination
 *    ?page=1
 *    ?limit=10                 (max 100)
 *
 *  Search  (matches fullName, email, designation)
 *    ?search=john
 *
 *  Exact-match filters  (all optional, all combinable)
 *    ?department=Engineering
 *    ?department=Product+Design
 *    ?department=Marketing
 *    ?department=Sales
 *    ?department=HR
 *    ?department=Finance
 *    ?department=Operations
 *    ?department=Legal
 *
 *    ?status=Active
 *    ?status=Inactive
 *    ?status=On+Leave
 *    ?status=Terminated
 *
 *    ?employmentType=Full-time+Regular
 *    ?employmentType=Full-time+Contract
 *    ?employmentType=Part-time
 *    ?employmentType=Internship
 *
 *  Sorting
 *    ?sort=joiningDate         (default: createdAt)
 *    ?sort=fullName
 *    ?sort=department
 *    ?sort=designation
 *    ?sort=status
 *    ?sort=employeeId
 *    ?sort=updatedAt
 *    ?order=asc                (default: desc)
 *    ?order=desc
 *
 *  Combined examples
 *    /api/employees?search=john&department=Engineering&sort=joiningDate&order=asc
 *    /api/employees?status=Active&page=2&limit=25
 *    /api/employees?department=HR&status=Active&sort=fullName&order=asc
 *    /api/employees?sort=joiningDate&order=desc&page=1&limit=10
 */

const express  = require('express');
const router   = express.Router();

const empCtrl  = require('../controllers/employeeController');
const { protect, authorize } = require('../middleware/authMiddleware');
const {
  validate,
  listQueryRules,
  createEmployeeRules,
  updateEmployeeRules,
  mongoIdParam,
} = require('../validations/employeeValidation');

// ── All employee routes require a valid JWT ───────────────────────────────────

router.use(protect);

// ── Static sub-routes (must be declared BEFORE /:id) ─────────────────────────
// Express matches routes top-down; if /:id comes first, 'stats' would be
// treated as an id and fail the MongoId validation.

router.get('/stats',       empCtrl.getStats);
router.get('/recent',      empCtrl.getRecent);
router.get('/departments', empCtrl.getDepartmentBreakdown);
router.get('/search',      empCtrl.search);

// ── Collection routes ─────────────────────────────────────────────────────────

router.get(
  '/',
  listQueryRules,   // validate page, limit, search, department, status, sort, order
  validate,
  empCtrl.getAll,
);

router.post(
  '/',
  authorize('admin', 'hr'),
  createEmployeeRules,
  validate,
  empCtrl.create,
);

// ── Document routes (/api/employees/:id) ─────────────────────────────────────

router.get(
  '/:id',
  mongoIdParam(),
  validate,
  empCtrl.getById,
);

router.put(
  '/:id',
  authorize('admin', 'hr'),
  mongoIdParam(),
  updateEmployeeRules,
  validate,
  empCtrl.update,
);

router.delete(
  '/:id',
  authorize('admin'),
  mongoIdParam(),
  validate,
  empCtrl.remove,
);

module.exports = router;
