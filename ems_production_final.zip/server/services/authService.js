const bcrypt                               = require('bcryptjs');
const User                                 = require('../models/User');
const { signAccessToken, signRefreshToken,
        verifyRefreshToken }               = require('../utils/jwt');

// ─── register ─────────────────────────────────────────────────────────────────

const register = async ({ name, email, password, role }) => {
  // Check uniqueness (Mongoose unique index also guards this, but gives a better message here)
  const existing = await User.findOne({ email });
  if (existing) {
    const err = new Error('An account with this email already exists.');
    err.statusCode = 409;
    throw err;
  }

  const user = await User.create({ name, email, password, role });

  const accessToken  = signAccessToken({ id: user._id, role: user.role });
  const refreshToken = signRefreshToken({ id: user._id });

  // Store hashed refresh token
  const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 12;
  user.refreshToken = await bcrypt.hash(refreshToken, saltRounds);
  await user.save({ validateBeforeSave: false });

  return { user: user.toPublicJSON(), accessToken, refreshToken };
};

// ─── login ────────────────────────────────────────────────────────────────────

const login = async ({ email, password }) => {
  // Explicitly select password (excluded by default via `select: false`)
  const user = await User.findOne({ email }).select('+password');

  if (!user || !(await user.comparePassword(password))) {
    const err = new Error('Invalid email or password.');
    err.statusCode = 401;
    throw err;
  }

  if (!user.isActive) {
    const err = new Error('Your account has been deactivated. Contact admin.');
    err.statusCode = 403;
    throw err;
  }

  const accessToken  = signAccessToken({ id: user._id, role: user.role });
  const refreshToken = signRefreshToken({ id: user._id });

  // Persist hashed refresh token + update lastLogin
  const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 12;
  user.refreshToken = await bcrypt.hash(refreshToken, saltRounds);
  user.lastLogin    = new Date();
  await user.save({ validateBeforeSave: false });

  return { user: user.toPublicJSON(), accessToken, refreshToken };
};

// ─── refresh ──────────────────────────────────────────────────────────────────

const refreshAccessToken = async (refreshToken) => {
  let decoded;
  try {
    decoded = verifyRefreshToken(refreshToken);
  } catch {
    const err = new Error('Invalid or expired refresh token.');
    err.statusCode = 401;
    throw err;
  }

  const user = await User.findById(decoded.id).select('+refreshToken');
  if (!user || !user.refreshToken) {
    const err = new Error('Refresh token not found. Please log in again.');
    err.statusCode = 401;
    throw err;
  }

  const isValid = await bcrypt.compare(refreshToken, user.refreshToken);
  if (!isValid) {
    const err = new Error('Refresh token is invalid or has been revoked.');
    err.statusCode = 401;
    throw err;
  }

  // Rotate: issue new pair
  const newAccessToken  = signAccessToken({ id: user._id, role: user.role });
  const newRefreshToken = signRefreshToken({ id: user._id });

  const saltRounds = parseInt(process.env.BCRYPT_SALT_ROUNDS, 10) || 12;
  user.refreshToken = await bcrypt.hash(newRefreshToken, saltRounds);
  await user.save({ validateBeforeSave: false });

  return { accessToken: newAccessToken, refreshToken: newRefreshToken };
};

// ─── logout ───────────────────────────────────────────────────────────────────

const logout = async (userId) => {
  await User.findByIdAndUpdate(userId, { $unset: { refreshToken: '' } });
};

// ─── getProfile ───────────────────────────────────────────────────────────────

const getProfile = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    const err = new Error('User not found.');
    err.statusCode = 404;
    throw err;
  }
  return user.toPublicJSON();
};

module.exports = { register, login, refreshAccessToken, logout, getProfile };
