const Employee = require('../models/Employee');

// ─── Sortable fields whitelist ────────────────────────────────────────────────
// Maps the public-facing ?sort= value to the actual Mongoose field name.
// Only fields in this map are allowed — prevents arbitrary field injection.

const SORT_FIELD_MAP = {
  joiningDate:  'joiningDate',
  createdAt:    'createdAt',
  updatedAt:    'updatedAt',
  fullName:     'fullName',
  department:   'department',
  designation:  'designation',
  employeeId:   'employeeId',
  status:       'status',
};

const DEFAULT_SORT_FIELD = 'createdAt';
const DEFAULT_SORT_ORDER = 'desc';

// ─── buildFilter ─────────────────────────────────────────────────────────────
//
// Converts raw query-string params into a MongoDB filter document.
//
// Search strategy (two-tier):
//   ≥ 3 chars  → MongoDB Atlas text index ($text) for relevance ranking.
//                Covers fullName (weight 3), designation (weight 2), email (weight 1).
//   1–2 chars  → Regex fallback on fullName, email, employeeId.
//                Short strings score poorly on text indexes so regex is more useful here.
//
// All filters are ANDed together — e.g. department=Engineering&status=Active&search=john
// returns Engineering employees who are Active AND match "john".

const buildFilter = ({ search, department, status, employmentType }) => {
  const filter = {};

  // ── Exact-match filters ────────────────────────────────────────────────────
  if (department)      filter.department      = department;
  if (status)          filter.status          = status;
  if (employmentType)  filter.employmentType  = employmentType;

  // ── Search ────────────────────────────────────────────────────────────────
  if (search && search.trim().length > 0) {
    const q = search.trim();

    if (q.length >= 3) {
      // Full-text search — uses compound text index on fullName / designation / email.
      // $text cannot be combined with $or at the top level, so we add it as a
      // top-level key (MongoDB ANDs all top-level filter keys automatically).
      filter.$text = { $search: q };
    } else {
      // Regex fallback for 1-2 char queries (text index ignores short tokens).
      filter.$or = [
        { fullName:   { $regex: q, $options: 'i' } },
        { email:      { $regex: q, $options: 'i' } },
        { employeeId: { $regex: q, $options: 'i' } },
      ];
    }
  }

  return filter;
};

// ─── buildSort ────────────────────────────────────────────────────────────────
//
// Converts ?sort=joiningDate&order=asc into a Mongoose sort object.
//
// Special case: when $text search is active, we can optionally include
// { score: { $meta: 'textScore' } } as a secondary sort to surface the
// most relevant results first. The caller passes `hasTextSearch` to enable this.
//
// order aliases: 'asc' | 'desc' | '1' | '-1' (all accepted)

const buildSort = (sort, order, hasTextSearch = false) => {
  const field     = SORT_FIELD_MAP[sort] || DEFAULT_SORT_FIELD;
  const direction = ['asc', '1'].includes(String(order).toLowerCase()) ? 1 : -1;

  const sortObj = {};

  // When doing text search, prepend relevance score so best matches come first,
  // then use the requested sort as a tiebreaker.
  if (hasTextSearch) {
    sortObj.score = { $meta: 'textScore' };
  }

  sortObj[field] = direction;
  return sortObj;
};

// ─── buildPagination ─────────────────────────────────────────────────────────
//
// Normalises and clamps page / limit values.
// Returns { page, limit, skip } ready for Mongoose .skip().limit().

const buildPagination = (rawPage, rawLimit) => {
  const page  = Math.max(1, parseInt(rawPage,  10) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(rawLimit, 10) || 10));
  const skip  = (page - 1) * limit;
  return { page, limit, skip };
};

// ─── getAll ───────────────────────────────────────────────────────────────────
//
// Supported query params:
//   page            – page number (default: 1)
//   limit           – results per page, max 100 (default: 10)
//   search          – full-text / regex search across name, email, designation
//   department      – exact match (Engineering | Product Design | …)
//   status          – exact match (Active | Inactive | On Leave | Terminated)
//   employmentType  – exact match (Full-time Regular | …)
//   sort            – field to sort by (default: createdAt)
//   order           – asc | desc (default: desc)
//
// Response shape: { employees: [...], meta: { total, page, limit, totalPages, hasNext, hasPrev } }

const getAll = async ({
  page: rawPage,
  limit: rawLimit,
  search,
  department,
  status,
  employmentType,
  sort     = DEFAULT_SORT_FIELD,
  order    = DEFAULT_SORT_ORDER,
} = {}) => {
  const filter          = buildFilter({ search, department, status, employmentType });
  const hasTextSearch   = Boolean(filter.$text);
  const sortObj         = buildSort(sort, order, hasTextSearch);
  const { page, limit, skip } = buildPagination(rawPage, rawLimit);

  // Projection: include text score only when a $text query is active.
  // Mongoose requires the score projection to be passed via .select() when
  // using $meta — we handle this by passing a projection object directly to .find().
  const projection = hasTextSearch ? { score: { $meta: 'textScore' } } : {};

  // Run the list query and the count query in parallel for efficiency.
  const [employees, total] = await Promise.all([
    Employee
      .find(filter, projection)
      .sort(sortObj)
      .skip(skip)
      .limit(limit)
      .populate('createdBy', 'name email')
      .populate('updatedBy', 'name email')
      .lean(),
    Employee.countDocuments(filter),
  ]);

  return {
    employees,
    meta: {
      total,
      page,
      limit,
      totalPages: Math.ceil(total / limit),
      hasNext:    skip + employees.length < total,
      hasPrev:    page > 1,
    },
  };
};

// ─── getById ──────────────────────────────────────────────────────────────────

const getById = async (id) => {
  const employee = await Employee
    .findById(id)
    .populate('createdBy', 'name email role')
    .populate('updatedBy', 'name email role');

  if (!employee) {
    const err = new Error('Employee not found.');
    err.statusCode = 404;
    throw err;
  }

  return employee;
};

// ─── create ───────────────────────────────────────────────────────────────────

const create = async (data, userId) => {
  const employee = await Employee.create({ ...data, createdBy: userId });

  // Re-fetch with populated refs so the response matches GET shape.
  return Employee
    .findById(employee._id)
    .populate('createdBy', 'name email');
};

// ─── update ───────────────────────────────────────────────────────────────────

const update = async (id, data, userId) => {
  // Strip fields that must never be updated via this endpoint.
  const { employeeId: _eid, createdBy: _cb, createdAt: _ca, ...safeData } = data;

  const employee = await Employee
    .findByIdAndUpdate(
      id,
      { ...safeData, updatedBy: userId },
      { new: true, runValidators: true }
    )
    .populate('createdBy', 'name email')
    .populate('updatedBy', 'name email');

  if (!employee) {
    const err = new Error('Employee not found.');
    err.statusCode = 404;
    throw err;
  }

  return employee;
};

// ─── remove ───────────────────────────────────────────────────────────────────

const remove = async (id) => {
  const employee = await Employee.findByIdAndDelete(id);

  if (!employee) {
    const err = new Error('Employee not found.');
    err.statusCode = 404;
    throw err;
  }

  return employee;
};

// ─── getDashboardStats ────────────────────────────────────────────────────────
//
// Returns counts used by the Dashboard StatCards.
// Uses a single $facet aggregation — one round-trip to MongoDB.

const getDashboardStats = async () => Employee.getDashboardStats();

// ─── getRecent ────────────────────────────────────────────────────────────────
//
// Latest N employees sorted by creation date — used by the Dashboard table.

const getRecent = async (limit = 4) =>
  Employee
    .find()
    .sort({ createdAt: -1 })
    .limit(limit)
    .populate('createdBy', 'name')
    .lean();

// ─── globalSearch ─────────────────────────────────────────────────────────────
//
// Lightweight search endpoint for the Navbar search bar.
// Returns a small projection — no pagination, capped at `limit`.

const globalSearch = async (q, limit = 8) => {
  if (!q || q.trim().length < 2) return [];

  const trimmed = q.trim();

  // For short queries use regex; for longer use text index.
  const filter = trimmed.length >= 3
    ? { $text: { $search: trimmed } }
    : {
        $or: [
          { fullName:   { $regex: trimmed, $options: 'i' } },
          { email:      { $regex: trimmed, $options: 'i' } },
          { employeeId: { $regex: trimmed, $options: 'i' } },
        ],
      };

  const projection = trimmed.length >= 3
    ? { score: { $meta: 'textScore' } }
    : {};

  const sortObj = trimmed.length >= 3
    ? { score: { $meta: 'textScore' } }
    : { fullName: 1 };

  return Employee
    .find(filter, projection)
    .sort(sortObj)
    .limit(Number(limit))
    .select('employeeId fullName email department designation status')
    .lean();
};

// ─── getDepartmentBreakdown ───────────────────────────────────────────────────
//
// Aggregation returning employee count per department.
// Useful for future analytics pages.

const getDepartmentBreakdown = async () =>
  Employee.aggregate([
    {
      $group: {
        _id:   '$department',
        count: { $sum: 1 },
        active: {
          $sum: { $cond: [{ $eq: ['$status', 'Active'] }, 1, 0] },
        },
      },
    },
    { $sort: { count: -1 } },
    {
      $project: {
        _id:        0,
        department: '$_id',
        total:      '$count',
        active:     1,
      },
    },
  ]);

module.exports = {
  getAll,
  getById,
  create,
  update,
  remove,
  getDashboardStats,
  getRecent,
  globalSearch,
  getDepartmentBreakdown,
  // expose constants so callers can build dropdowns
  SORT_FIELD_MAP,
};
