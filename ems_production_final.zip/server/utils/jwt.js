const jwt = require('jsonwebtoken');

// ─── Sign access token ────────────────────────────────────────────────────────

/**
 * Generate a short-lived access token.
 * @param {object} payload  — e.g. { id, role }
 * @returns {string}
 */
const signAccessToken = (payload) =>
  jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '7d',
  });

// ─── Sign refresh token ───────────────────────────────────────────────────────

/**
 * Generate a long-lived refresh token.
 * @param {object} payload  — e.g. { id }
 * @returns {string}
 */
const signRefreshToken = (payload) =>
  jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d',
  });

// ─── Verify access token ─────────────────────────────────────────────────────

/**
 * Verify and decode an access token.
 * Throws JsonWebTokenError / TokenExpiredError on failure.
 * @param {string} token
 * @returns {object}  decoded payload
 */
const verifyAccessToken = (token) =>
  jwt.verify(token, process.env.JWT_SECRET);

// ─── Verify refresh token ────────────────────────────────────────────────────

/**
 * Verify and decode a refresh token.
 * @param {string} token
 * @returns {object}  decoded payload
 */
const verifyRefreshToken = (token) =>
  jwt.verify(token, process.env.JWT_REFRESH_SECRET);

// ─── Cookie options ───────────────────────────────────────────────────────────

const refreshCookieOptions = {
  httpOnly: true,
  secure:   process.env.NODE_ENV === 'production',
  sameSite: 'strict',
  maxAge:   30 * 24 * 60 * 60 * 1000,  // 30 days in ms
  path:     '/api/auth/refresh',
};

module.exports = {
  signAccessToken,
  signRefreshToken,
  verifyAccessToken,
  verifyRefreshToken,
  refreshCookieOptions,
};
