/**
 * Send a success response.
 * @param {object} res
 * @param {number} statusCode
 * @param {string} message
 * @param {*}      data
 * @param {object} [meta]   — optional pagination metadata
 */
const sendSuccess = (res, statusCode = 200, message, data = null, meta = null) => {
  const payload = { success: true, message };
  if (data !== null) payload.data = data;
  if (meta !== null) payload.meta = meta;
  return res.status(statusCode).json(payload);
};

/**
 * Send an error response.
 * @param {object} res
 * @param {number} statusCode
 * @param {string} message
 * @param {Array}  [errors]  — field-level validation errors
 */
const sendError = (res, statusCode = 500, message, errors = null) => {
  const payload = { success: false, message };
  if (errors) payload.errors = errors;
  return res.status(statusCode).json(payload);
};

module.exports = { sendSuccess, sendError };
