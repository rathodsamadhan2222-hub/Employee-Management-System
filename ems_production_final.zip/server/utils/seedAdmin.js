/**
 * Seed script — creates the initial admin user.
 * Run once:  node utils/seedAdmin.js
 */

require('dotenv').config({ path: require('path').resolve(__dirname, '../.env') });
const mongoose = require('mongoose');
const User     = require('../models/User');

const seed = async () => {
  await mongoose.connect(process.env.MONGO_URI);
  console.log('🗄️  Connected to MongoDB');

  const existing = await User.findOne({ email: 'admin@hrprecision.com' });
  if (existing) {
    console.log('ℹ️  Admin user already exists. Skipping seed.');
    process.exit(0);
  }

  await User.create({
    name:     'Alex Thompson',
    email:    'admin@hrprecision.com',
    password: 'Admin@1234',   // will be hashed by pre-save hook
    role:     'admin',
  });

  console.log('✅  Admin user created:');
  console.log('    Email   : admin@hrprecision.com');
  console.log('    Password: Admin@1234');
  console.log('    ⚠️  Change this password after first login!');
  process.exit(0);
};

seed().catch((err) => {
  console.error('❌  Seed failed:', err.message);
  process.exit(1);
});
