const { body, query, param, validationResult } = require('express-validator');
const { sendError }                             = require('../utils/response');
const { DEPARTMENTS, EMPLOYMENT_TYPES, STATUS } = require('../models/Employee');

// ─── Allowed sort fields (mirrors service SORT_FIELD_MAP keys) ───────────────

const SORT_FIELDS = [
  'joiningDate',
  'createdAt',
  'updatedAt',
  'fullName',
  'department',
  'designation',
  'employeeId',
  'status',
];

// ─── Shared validation runner ─────────────────────────────────────────────────
//
// Mount this AFTER your rule arrays in a route definition:
//   router.get('/', listQueryRules, validate, controller.getAll)
//
// Collects all express-validator errors, formats them as { field, message }
// pairs, and short-circuits with HTTP 422 if any errors exist.

const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const formatted = errors.array().map((e) => ({
      field:   e.path,
      message: e.msg,
    }));
    return sendError(res, 422, 'Validation failed', formatted);
  }
  next();
};

// ─── List query rules — GET /api/employees ────────────────────────────────────
//
// Validates all supported query parameters for the employee list endpoint.
// All rules are optional — an empty query returns the first page of all employees.

const listQueryRules = [

  // Pagination
  query('page')
    .optional()
    .isInt({ min: 1 })
    .withMessage('page must be a positive integer (e.g. ?page=2)')
    .toInt(),

  query('limit')
    .optional()
    .isInt({ min: 1, max: 100 })
    .withMessage('limit must be between 1 and 100 (e.g. ?limit=25)')
    .toInt(),

  // Search — validated for length to avoid empty-string queries
  query('search')
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage('search must be 1–100 characters'),

  // Exact-match filters
  query('department')
    .optional()
    .trim()
    .isIn(DEPARTMENTS)
    .withMessage(`department must be one of: ${DEPARTMENTS.join(', ')}`),

  query('status')
    .optional()
    .trim()
    .isIn(STATUS)
    .withMessage(`status must be one of: ${STATUS.join(', ')}`),

  query('employmentType')
    .optional()
    .trim()
    .isIn(EMPLOYMENT_TYPES)
    .withMessage(`employmentType must be one of: ${EMPLOYMENT_TYPES.join(', ')}`),

  // Sorting
  query('sort')
    .optional()
    .trim()
    .isIn(SORT_FIELDS)
    .withMessage(`sort must be one of: ${SORT_FIELDS.join(', ')}`),

  query('order')
    .optional()
    .trim()
    .isIn(['asc', 'desc'])
    .withMessage("order must be 'asc' or 'desc'"),

];

// ─── Body rules — shared between create and update ────────────────────────────
//
// isUpdate = true  →  every field is optional (PATCH semantics on PUT).
// isUpdate = false →  required fields throw if missing.

const employeeBodyRules = (isUpdate = false) => {
  // Wraps a chain to make it optional when updating.
  const opt = (chain) => (isUpdate ? chain.optional() : chain);

  return [

    // ── Personal Information ──────────────────────────────────────────────

    opt(body('fullName'))
      .trim()
      .notEmpty().withMessage('Full name is required')
      .isLength({ min: 2, max: 80 })
      .withMessage('Full name must be 2–80 characters'),

    opt(body('email'))
      .trim()
      .notEmpty().withMessage('Email is required')
      .isEmail().withMessage('Please provide a valid email address')
      .normalizeEmail(),

    body('mobileNumber')
      .optional()
      .trim()
      .matches(/^\+?[1-9]\d{1,14}$/)
      .withMessage('Provide a valid mobile number in E.164 format (e.g. +919876543210)'),

    body('dateOfBirth')
      .optional()
      .isISO8601().withMessage('Date of birth must be a valid ISO date (YYYY-MM-DD)')
      .custom((val) => {
        const dob  = new Date(val);
        const now  = new Date();
        const age  = (now - dob) / (1000 * 60 * 60 * 24 * 365.25);
        if (age < 16)  throw new Error('Employee must be at least 16 years old');
        if (age > 100) throw new Error('Date of birth is not realistic');
        return true;
      }),

    // ── Job Details ──────────────────────────────────────────────────────

    opt(body('department'))
      .notEmpty().withMessage('Department is required')
      .isIn(DEPARTMENTS)
      .withMessage(`Department must be one of: ${DEPARTMENTS.join(', ')}`),

    opt(body('designation'))
      .trim()
      .notEmpty().withMessage('Designation is required')
      .isLength({ min: 2, max: 100 })
      .withMessage('Designation must be 2–100 characters'),

    body('employmentType')
      .optional()
      .isIn(EMPLOYMENT_TYPES)
      .withMessage(`Employment type must be one of: ${EMPLOYMENT_TYPES.join(', ')}`),

    opt(body('joiningDate'))
      .notEmpty().withMessage('Joining date is required')
      .isISO8601().withMessage('Joining date must be a valid ISO date (YYYY-MM-DD)')
      .custom((val) => {
        const joining = new Date(val);
        const max     = new Date();
        max.setFullYear(max.getFullYear() + 1);  // allow up to 1 year in the future
        if (joining > max) throw new Error('Joining date cannot be more than 1 year in the future');
        return true;
      }),

    // ── Status ───────────────────────────────────────────────────────────

    body('status')
      .optional()
      .isIn(STATUS)
      .withMessage(`Status must be one of: ${STATUS.join(', ')}`),

  ];
};

// ─── Named rule sets ──────────────────────────────────────────────────────────

const createEmployeeRules = employeeBodyRules(false);
const updateEmployeeRules = employeeBodyRules(true);

// ─── MongoDB ObjectId param validation ───────────────────────────────────────

const mongoIdParam = (paramName = 'id') => [
  param(paramName)
    .isMongoId()
    .withMessage(`'${paramName}' must be a valid MongoDB ObjectId`),
];

// ─── Exports ──────────────────────────────────────────────────────────────────

module.exports = {
  validate,
  listQueryRules,
  createEmployeeRules,
  updateEmployeeRules,
  mongoIdParam,
  SORT_FIELDS,
};
